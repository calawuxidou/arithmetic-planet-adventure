import { createCombatQuestion, seededRandom } from "/shared/questions.js";
import { CHAPTERS, LEVELS, ENEMY_TYPES, UPGRADE_CARDS, WEAPONS, bossWeakness, computeAttack } from "/shared/game-data.js";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

const elements = {
  screens: $$(".screen"), home: $("#screen-home"), map: $("#screen-map"), battle: $("#screen-battle"), game: $("#screen-game"), result: $("#screen-result"),
  soundToggle: $("#sound-toggle"), gameSound: $("#game-sound"), campaignStart: $("#campaign-start"), levelOpen: $("#level-open"), battleOpen: $("#battle-open"), mapBack: $("#map-back"),
  homeChapter: $("#home-chapter"), homeProgressText: $("#home-progress-text"), homeProgressFill: $("#home-progress-fill"), homeLevel: $("#home-current-level"), homeMission: $("#home-mission"),
  chapterTabs: $("#chapter-tabs"), mapChapterHead: $("#map-chapter-head"), levelGrid: $("#level-grid"), mapStars: $("#map-stars"),
  battleEntry: $("#battle-entry"), battleLobby: $("#battle-lobby"), playerName: $("#player-name"), codeInput: $("#room-code-input"), createRoom: $("#create-room"), joinRoom: $("#join-room"), battleError: $("#battle-error"), networkStatus: $("#network-status"), roomCode: $("#room-code"), copyCode: $("#copy-code"), waitingCopy: $("#waiting-copy"), ready: $("#ready-button"), playerSlots: [$("#player-one"), $("#player-two")],
  soloHud: $("#solo-hud"), battleHud: $("#battle-hud"), core: $("#core-display"), wave: $("#wave-display"), combo: $("#combo-display"), score: $("#score-display"), myCore: $("#my-core"), rivalCore: $("#rival-core"), myKills: $("#my-kills"), rivalKills: $("#rival-kills"), battleRound: $("#battle-round"),
  gameExit: $("#game-exit"), missionType: $("#mission-type"), missionTitle: $("#mission-title"), objectiveWrap: $("#objective-wrap"), objectiveFill: $("#objective-fill"), objectiveLabel: $("#objective-label"), enemyCount: $("#enemy-count"),
  world: $("#game-world"), enemyLayer: $("#enemy-layer"), projectileLayer: $("#projectile-layer"), battleEffect: $("#battle-effect"), defender: $("#defender"), energyCore: $("#energy-core"), bossPhase: $("#boss-phase"), bossWeakness: $("#boss-weakness"), targetTip: $("#target-tip"),
  difficultySelector: $("#difficulty-selector"), difficulties: $$(".difficulty"), weaponIcon: $("#weapon-icon"), weaponName: $("#weapon-name"), questionMeta: $("#question-meta"), expression: $("#expression"), timeFill: $("#time-fill"), answers: $$(".answer-option"), feedback: $("#feedback"),
  tacticSelector: $("#tactic-selector"), tacticButtons: $$("[data-tactic]"), portalMeter: $("#portal-meter"), portalDots: $("#portal-dots"), countdown: $("#countdown-overlay"), upgradeOverlay: $("#upgrade-overlay"), upgradeCards: $("#upgrade-cards"),
  resultStars: $("#result-stars"), resultKicker: $("#result-kicker"), resultTitle: $("#result-title"), resultScore: $("#result-score"), resultKills: $("#result-kills"), resultCombo: $("#result-combo"), resultCore: $("#result-core"), battleRanking: $("#battle-ranking"), playAgain: $("#play-again"), resultMap: $("#result-map"), resultHome: $("#result-home"), toast: $("#toast")
};

function readNumber(key, fallback) {
  const value = Number(localStorage.getItem(key));
  return Number.isFinite(value) ? value : fallback;
}

function readStars() {
  try { return JSON.parse(localStorage.getItem("arithmetic-level-stars") || "{}"); }
  catch { return {}; }
}

const campaign = {
  unlocked: clamp(readNumber("arithmetic-unlocked-level", 1), 1, LEVELS.length),
  selectedLevel: clamp(readNumber("arithmetic-selected-level", 1), 1, LEVELS.length),
  stars: readStars(),
  chapter: 1
};

let currentGame = null;
let solo = null;
let soundEnabled = localStorage.getItem("arithmetic-sound") !== "off";
let audioContext = null;
let toastTimer = null;
let effectTimer = null;
let lastResult = { type: "solo", levelId: 1, success: true };

const battle = {
  socket: null, connecting: null, playerId: null, token: sessionStorage.getItem("arithmetic-battle-token"), room: null,
  question: null, locked: false, tactic: "raid", countdownTimer: null
};

function showScreen(target) {
  for (const screen of elements.screens) screen.classList.toggle("active", screen === target);
  window.scrollTo({ top: 0, behavior: "instant" });
}

function playTone(kind) {
  if (!soundEnabled) return;
  try {
    audioContext ||= new AudioContext();
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    const settings = {
      select: [430, .05, "sine"], shot: [760, .09, "square"], laser: [940, .16, "sawtooth"], explosion: [135, .23, "sawtooth"], correct: [680, .14, "triangle"], wrong: [170, .18, "sawtooth"], win: [880, .35, "triangle"]
    }[kind] || [400, .08, "sine"];
    oscillator.type = settings[2];
    oscillator.frequency.setValueAtTime(settings[0], audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(60, settings[0] * (kind === "explosion" ? .45 : 1.35)), audioContext.currentTime + settings[1]);
    gain.gain.setValueAtTime(.045, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + settings[1]);
    oscillator.connect(gain).connect(audioContext.destination);
    oscillator.start(); oscillator.stop(audioContext.currentTime + settings[1]);
  } catch { /* Decorative audio must never block play. */ }
}

function updateSoundButtons() {
  const symbol = soundEnabled ? "♫" : "♪";
  elements.soundToggle.textContent = symbol; elements.gameSound.textContent = symbol;
  elements.soundToggle.setAttribute("aria-label", soundEnabled ? "关闭音效" : "开启音效");
  elements.gameSound.setAttribute("aria-label", soundEnabled ? "关闭音效" : "开启音效");
}

function toggleSound() {
  soundEnabled = !soundEnabled;
  localStorage.setItem("arithmetic-sound", soundEnabled ? "on" : "off");
  updateSoundButtons(); if (soundEnabled) playTone("select");
}

function toast(message) {
  clearTimeout(toastTimer); elements.toast.textContent = message; elements.toast.classList.add("show");
  toastTimer = setTimeout(() => elements.toast.classList.remove("show"), 1800);
}

function showBattleEffect(message, style = "") {
  clearTimeout(effectTimer); elements.battleEffect.className = `battle-effect ${style}`.trim(); elements.battleEffect.textContent = message;
  effectTimer = setTimeout(() => elements.battleEffect.classList.add("hidden"), 1500);
}

function currentLevel() { return LEVELS[campaign.selectedLevel - 1] || LEVELS[0]; }

function persistCampaign() {
  localStorage.setItem("arithmetic-unlocked-level", String(campaign.unlocked));
  localStorage.setItem("arithmetic-selected-level", String(campaign.selectedLevel));
  localStorage.setItem("arithmetic-level-stars", JSON.stringify(campaign.stars));
}

function renderHome() {
  if (campaign.selectedLevel > campaign.unlocked) campaign.selectedLevel = campaign.unlocked;
  const level = currentLevel(); const chapter = CHAPTERS[level.chapter - 1];
  elements.homeChapter.textContent = `第${chapter.id}章 · ${chapter.name}`;
  elements.homeProgressText.textContent = `${campaign.unlocked} / ${LEVELS.length}`;
  elements.homeProgressFill.style.width = `${(campaign.unlocked / LEVELS.length) * 100}%`;
  elements.homeLevel.textContent = `第${level.id}关 ${level.name}`;
  elements.homeMission.textContent = level.description;
}

function totalStars() { return Object.values(campaign.stars).reduce((sum, value) => sum + Number(value || 0), 0); }

function renderMap(chapterId = campaign.chapter) {
  campaign.chapter = clamp(chapterId, 1, CHAPTERS.length);
  elements.chapterTabs.innerHTML = CHAPTERS.map((chapter) => `<button role="tab" aria-selected="${chapter.id === campaign.chapter}" class="${chapter.id === campaign.chapter ? "active" : ""}" data-chapter="${chapter.id}">${chapter.id}</button>`).join("");
  const chapter = CHAPTERS[campaign.chapter - 1];
  elements.mapChapterHead.innerHTML = `<small>第${chapter.id}章</small><h3>${chapter.name}</h3><p>${chapter.description}</p>`;
  elements.mapStars.textContent = `★ ${totalStars()}`;
  const levels = LEVELS.filter((level) => level.chapter === campaign.chapter);
  elements.levelGrid.innerHTML = levels.map((level) => {
    const unlocked = level.id <= campaign.unlocked; const stars = campaign.stars[level.id] || 0;
    return `<button class="level-node ${unlocked ? "" : "locked"} ${campaign.selectedLevel === level.id ? "selected" : ""}" data-level="${level.id}" ${unlocked ? "" : "disabled"}>
      <span class="level-number">${unlocked ? level.id : "◆"}</span><span class="level-info"><small>${level.missionName}</small><strong>${level.name}</strong><i>${"★".repeat(stars)}${"☆".repeat(3 - stars)}</i></span><b>›</b>
    </button>`;
  }).join("");
}

function openMap() {
  const level = currentLevel(); campaign.chapter = level.chapter; renderMap(); showScreen(elements.map);
}

function cleanupSolo() {
  if (!solo) return;
  clearTimeout(solo.questionTimer); clearInterval(solo.loopTimer);
  for (const timer of solo.spawnTimers) clearTimeout(timer);
  solo.spawnTimers.clear();
}

function resetBattlefield() {
  elements.enemyLayer.innerHTML = ""; elements.projectileLayer.innerHTML = "";
  elements.world.className = "game-world"; elements.energyCore.className = "energy-core";
  elements.bossPhase.classList.add("hidden"); elements.upgradeOverlay.classList.add("hidden");
  elements.feedback.classList.add("hidden"); elements.battleEffect.classList.add("hidden");
}

function startSoloLevel(levelId = campaign.selectedLevel) {
  cleanupSolo(); currentGame = "solo"; campaign.selectedLevel = clamp(levelId, 1, campaign.unlocked); persistCampaign();
  const level = currentLevel();
  solo = {
    level, waveIndex: 0, enemies: new Map(), selectedEnemyId: null, coreHealth: level.coreHealth, score: 0, kills: 0,
    combo: 0, bestCombo: 0, correct: 0, answered: 0, difficulty: 1, question: null, questionCounter: 0,
    questionStartedAt: 0, questionTimer: null, loopTimer: null, spawnTimers: new Set(), pendingSpawns: 0,
    active: true, locked: false, inTransition: false, objective: 0, bonusWaves: 0, upgrades: [], comboGuardUsed: false,
    lastTick: Date.now(), killHealCounter: 0
  };
  resetBattlefield(); elements.game.classList.remove("battle-mode"); elements.soloHud.classList.remove("hidden"); elements.battleHud.classList.add("hidden");
  elements.difficultySelector.classList.remove("hidden"); elements.tacticSelector.classList.add("hidden"); elements.portalMeter.classList.add("hidden");
  elements.missionType.textContent = level.missionName; elements.missionTitle.textContent = `第${level.id}关 ${level.name}`;
  elements.objectiveWrap.classList.toggle("hidden", !level.objectiveTarget); elements.targetTip.textContent = "点击魔鬼锁定目标 · 未选择时自动攻击最危险目标";
  setDifficulty(1, false); updateSoloHud(); showScreen(elements.game); startWave(0);
  solo.loopTimer = setInterval(updateWorld, 100); renderSoloQuestion(); playTone("select");
}

function updateSoloHud() {
  if (!solo) return;
  elements.core.textContent = Math.ceil(solo.coreHealth); elements.wave.textContent = `${Math.min(3, solo.waveIndex + 1)}/3`;
  elements.combo.textContent = solo.combo; elements.score.textContent = solo.score; elements.enemyCount.textContent = `魔鬼 ${solo.enemies.size + solo.pendingSpawns}`;
  elements.core.parentElement.classList.toggle("danger", solo.coreHealth <= 35);
  if (solo.level.objectiveTarget) {
    const label = solo.level.mission === "rescue" ? "救援" : "护送";
    elements.objectiveFill.style.width = `${solo.objective}%`; elements.objectiveLabel.textContent = `${label} ${Math.round(solo.objective)}%`;
  }
}

function startWave(index, bonus = false) {
  if (!solo?.active) return;
  solo.waveIndex = index; solo.inTransition = false; solo.comboGuardUsed = false;
  const level = solo.level; let count = bonus ? 4 : level.waves[index];
  const bossType = level.enemyPool.find((type) => ENEMY_TYPES[type]?.boss);
  if (index === 2 && bossType) count = 1;
  const rng = seededRandom(`wave-${level.id}-${index}-${solo.bonusWaves}`);
  const pool = level.enemyPool.filter((type) => !ENEMY_TYPES[type]?.boss);
  const schedule = [];
  for (let i = 0; i < count; i += 1) schedule.push(index === 2 && bossType ? bossType : pool[Math.floor(rng() * pool.length)] || "imp");
  solo.pendingSpawns += schedule.length;
  schedule.forEach((type, spawnIndex) => {
    const spawn = () => {
      if (!solo?.active) return;
      solo.pendingSpawns -= 1; spawnEnemy(type, Math.floor(rng() * 3)); updateSoloHud();
    };
    if (spawnIndex === 0) spawn();
    else {
      const timer = setTimeout(() => { solo?.spawnTimers.delete(timer); spawn(); }, spawnIndex * (bossType ? 1100 : 780));
      solo.spawnTimers.add(timer);
    }
  });
  updateSoloHud();
  showBattleEffect(bonus ? "护送尚未完成！增援正在靠近" : `第 ${index + 1} 波来袭`, index === 2 ? "danger" : "");
}

function enemyMarkup(enemy) {
  const config = ENEMY_TYPES[enemy.type];
  if (config.boss) return `<span class="boss-art"><img src="/assets/boss.webp" alt="" /></span><span class="enemy-name">${config.name}</span><span class="enemy-health"><i></i></span>`;
  return `<span class="monster"><i class="horn left"></i><i class="horn right"></i><b class="eye left"></b><b class="eye right"></b><em></em></span><span class="enemy-name">${config.name}</span><span class="enemy-health"><i></i></span>`;
}

function spawnEnemy(type, lane, progress = 0) {
  if (!solo) return null;
  const config = ENEMY_TYPES[type] || ENEMY_TYPES.imp;
  const maxHealth = Math.round(config.health * (1 + (solo.level.id - 1) * .018));
  const enemy = { id: `e-${Date.now()}-${Math.random().toString(16).slice(2)}`, type, lane, progress, health: maxHealth, maxHealth, boss: Boolean(config.boss), frozenUntil: 0, nextHealAt: Date.now() + 2800, nextSwitchAt: Date.now() + 2600, stole: false };
  const node = document.createElement("button");
  node.type = "button"; node.className = `enemy enemy-${type} ${config.boss ? "boss" : ""}`; node.dataset.enemyId = enemy.id;
  node.setAttribute("aria-label", `锁定${config.name}`); node.innerHTML = enemyMarkup(enemy); node.addEventListener("click", () => selectEnemy(enemy.id));
  enemy.node = node; solo.enemies.set(enemy.id, enemy); elements.enemyLayer.append(node); updateEnemyNode(enemy); return enemy;
}

function selectEnemy(id) {
  if (!solo?.enemies.has(id)) return;
  solo.selectedEnemyId = id;
  for (const enemy of solo.enemies.values()) enemy.node.classList.toggle("selected", enemy.id === id);
  playTone("select");
}

function updateEnemyNode(enemy) {
  const config = ENEMY_TYPES[enemy.type];
  enemy.node.style.left = `${[17, 50, 83][enemy.lane]}%`; enemy.node.style.top = `${5 + enemy.progress * .68}%`;
  enemy.node.querySelector(".enemy-health i").style.width = `${Math.max(0, enemy.health / enemy.maxHealth * 100)}%`;
  enemy.node.classList.toggle("frozen", enemy.frozenUntil > Date.now());
  if (enemy.boss) {
    const weakness = bossWeakness(enemy); elements.bossPhase.classList.remove("hidden");
    elements.bossWeakness.textContent = { divide: "除法 · 穿透激光", multiply: "乘法 · 分裂弹", mixed: "混合 · 星核火箭" }[weakness];
    enemy.node.dataset.weakness = weakness;
  }
}

function automaticTarget() {
  if (!solo?.enemies.size) return null;
  const selected = solo.enemies.get(solo.selectedEnemyId); if (selected) return selected;
  return [...solo.enemies.values()].sort((a, b) => (b.progress + ENEMY_TYPES[b.type].threat * 5) - (a.progress + ENEMY_TYPES[a.type].threat * 5))[0];
}

function updateWorld() {
  if (!solo?.active || solo.inTransition || currentGame !== "solo") return;
  const now = Date.now(); const delta = Math.min(400, now - solo.lastTick); solo.lastTick = now;
  for (const enemy of [...solo.enemies.values()]) {
    const config = ENEMY_TYPES[enemy.type]; const slowed = enemy.frozenUntil > now;
    enemy.progress += config.speed * (delta / 1000) * (slowed ? .22 : 1) * (1 + solo.level.chapter * .025);
    if (config.switchesLane && now >= enemy.nextSwitchAt) { enemy.lane = (enemy.lane + (Math.random() > .5 ? 1 : 2)) % 3; enemy.nextSwitchAt = now + 2800; }
    if (config.heals && now >= enemy.nextHealAt) {
      for (const ally of solo.enemies.values()) if (ally.id !== enemy.id && ally.lane === enemy.lane) ally.health = Math.min(ally.maxHealth, ally.health + 5);
      enemy.nextHealAt = now + 3000; enemy.node.classList.add("healing"); setTimeout(() => enemy.node?.classList.remove("healing"), 500);
    }
    if (config.steals && !enemy.stole && enemy.progress >= 62) { enemy.stole = true; solo.combo = Math.max(0, solo.combo - 2); showBattleEffect("偷能魔夺走了2格连击！", "danger"); }
    if (enemy.progress >= 100) breachCore(enemy); else updateEnemyNode(enemy);
  }
  updateSoloHud(); updateBossQuestionFocus();
}

function updateBossQuestionFocus() {
  if (!solo?.question || solo.locked) return;
  const boss = [...solo.enemies.values()].find((enemy) => enemy.boss); if (!boss) return;
  const weakness = bossWeakness(boss);
  if (solo.question.kind !== weakness) renderSoloQuestion();
}

function breachCore(enemy) {
  if (!solo?.enemies.has(enemy.id)) return;
  solo.coreHealth = Math.max(0, solo.coreHealth - ENEMY_TYPES[enemy.type].coreDamage); removeEnemy(enemy, false);
  elements.energyCore.classList.remove("hit"); void elements.energyCore.offsetWidth; elements.energyCore.classList.add("hit");
  elements.world.classList.add("core-hit"); setTimeout(() => elements.world.classList.remove("core-hit"), 380);
  showBattleEffect(`${ENEMY_TYPES[enemy.type].name}突破防线！`, "danger"); playTone("wrong"); updateSoloHud();
  if (solo.coreHealth <= 0) finishSolo(false); else checkWaveComplete();
}

function removeEnemy(enemy, killed) {
  if (!solo?.enemies.has(enemy.id)) return;
  solo.enemies.delete(enemy.id); enemy.node.classList.add(killed ? "defeated" : "breached"); setTimeout(() => enemy.node.remove(), 380);
  if (solo.selectedEnemyId === enemy.id) solo.selectedEnemyId = null;
  if (killed) {
    solo.kills += 1; solo.killHealCounter += 1;
    if (solo.upgrades.includes("killHeal") && solo.killHealCounter % 3 === 0) solo.coreHealth = Math.min(100, solo.coreHealth + 2);
    if (ENEMY_TYPES[enemy.type].splits) {
      spawnEnemy("imp", enemy.lane, Math.max(0, enemy.progress - 9)); spawnEnemy("imp", (enemy.lane + 1) % 3, Math.max(0, enemy.progress - 13));
      showBattleEffect("分裂魔变成了两只小恶魔！", "danger");
    }
  }
  updateSoloHud();
}

function animateProjectile(lane, weaponId, hit = true) {
  const projectile = document.createElement("span"); projectile.className = `projectile ${weaponId} lane-${lane} ${hit ? "" : "miss"}`;
  projectile.innerHTML = weaponId === "rocket" ? "☄" : weaponId === "frost" ? "❄" : weaponId === "laser" ? "" : "✦";
  elements.projectileLayer.append(projectile); setTimeout(() => projectile.remove(), 620);
  elements.defender.classList.remove("firing"); void elements.defender.offsetWidth; elements.defender.classList.add("firing");
  playTone(weaponId === "rocket" ? "explosion" : weaponId === "laser" ? "laser" : "shot");
}

function hitEnemy(enemy, rawDamage, attack) {
  if (!solo?.enemies.has(enemy.id)) return;
  let damage = rawDamage; const config = ENEMY_TYPES[enemy.type];
  if (config.armor && attack.kind !== "divide") damage *= config.armor;
  if (enemy.boss) {
    const weakness = bossWeakness(enemy);
    if (attack.kind === weakness) { damage *= 1.28; showBattleEffect("命中魔盾弱点！", "success"); }
    else { damage *= .32; showBattleEffect("武器类型不对，魔盾吸收了伤害", "danger"); }
  }
  enemy.health -= Math.max(1, Math.round(damage)); enemy.frozenUntil = Math.max(enemy.frozenUntil, Date.now() + attack.freezeMs);
  enemy.node.classList.remove("hit"); void enemy.node.offsetWidth; enemy.node.classList.add("hit"); setTimeout(() => enemy.node?.classList.remove("hit"), 260);
  animateProjectile(enemy.lane, attack.id);
  if (enemy.health <= 0) removeEnemy(enemy, true); else updateEnemyNode(enemy);
}

function fireAttack(attack) {
  const primary = automaticTarget(); if (!primary) { showBattleEffect("弹药已充能，等待下一只魔鬼", "success"); return 0; }
  const enemies = [...solo.enemies.values()].sort((a, b) => b.progress - a.progress); const hits = new Map();
  const addHit = (enemy, damage) => { if (enemy) hits.set(enemy.id, (hits.get(enemy.id) || 0) + damage); };
  if (attack.kind === "multiply") {
    const targets = [primary, ...enemies.filter((enemy) => enemy.id !== primary.id)];
    for (let index = 0; index < attack.projectiles; index += 1) addHit(targets[index % targets.length], attack.damage * (index ? .72 : 1));
  } else if (attack.kind === "divide") {
    const laneTargets = [primary, ...enemies.filter((enemy) => enemy.id !== primary.id && enemy.lane === primary.lane)];
    laneTargets.slice(0, attack.pierce).forEach((enemy, index) => addHit(enemy, attack.damage * (1 - index * .08)));
  } else if (attack.kind === "support") {
    for (const enemy of enemies.filter((item) => item.lane === primary.lane)) enemy.frozenUntil = Date.now() + attack.freezeMs;
    solo.coreHealth = Math.min(100, solo.coreHealth + attack.heal); addHit(primary, attack.damage * .62);
  } else {
    addHit(primary, attack.damage);
    enemies.filter((enemy) => enemy.id !== primary.id).slice(0, attack.splash + (attack.difficulty === 3 ? 2 : 0)).forEach((enemy) => addHit(enemy, attack.damage * .62));
  }
  const before = solo.kills;
  for (const [id, damage] of hits) { const target = solo.enemies.get(id); if (target) hitEnemy(target, damage, attack); }
  if (solo.upgrades.includes("drone") && solo.combo > 0 && solo.combo % 3 === 0) { const target = automaticTarget(); if (target) hitEnemy(target, 34, { ...attack, id: "scatter", kind: "multiply", freezeMs: 0 }); }
  if (solo.combo === 8) { for (const enemy of [...solo.enemies.values()]) hitEnemy(enemy, 28, { ...attack, id: "rocket", kind: "mixed", freezeMs: 400 }); showBattleEffect("8连击！无人机火力覆盖", "success"); }
  return solo.kills - before;
}

function setDifficulty(difficulty, rerender = true) {
  if (solo?.locked || currentGame === "battle") return;
  if (solo) solo.difficulty = clamp(Number(difficulty), 1, 3);
  for (const button of elements.difficulties) { const active = Number(button.dataset.difficulty) === (solo?.difficulty || 1); button.classList.toggle("active", active); button.setAttribute("aria-checked", String(active)); }
  if (rerender && solo?.active) { renderSoloQuestion(); playTone("select"); }
}

function setQuestionUI(question, durationMs, elapsedMs = 0) {
  const weapon = WEAPONS[question.kind] || WEAPONS.mixed;
  elements.weaponIcon.textContent = weapon.icon; elements.weaponName.textContent = weapon.name;
  elements.questionMeta.textContent = `${"★".repeat(question.difficulty)} ${question.category}`; elements.expression.textContent = question.expression;
  elements.answers.forEach((button, index) => { button.disabled = false; button.className = "answer-option"; button.querySelector("strong").textContent = question.choices[index]; button.dataset.answer = question.choices[index]; });
  elements.timeFill.classList.remove("active"); elements.timeFill.style.width = "100%"; elements.timeFill.style.setProperty("--question-time", `${Math.max(300, durationMs - elapsedMs)}ms`); void elements.timeFill.offsetWidth; elements.timeFill.classList.add("active");
  elements.feedback.classList.add("hidden");
}

function renderSoloQuestion() {
  if (!solo?.active || solo.inTransition) return;
  clearTimeout(solo.questionTimer); solo.locked = false; solo.questionCounter += 1;
  const boss = [...solo.enemies.values()].find((enemy) => enemy.boss);
  const focus = boss ? bossWeakness(boss) : solo.level.focus;
  const questionDifficulty = boss && focus === "mixed" ? Math.max(2, solo.difficulty) : solo.difficulty;
  solo.question = createCombatQuestion({ difficulty: questionDifficulty, focus, seed: `solo-${solo.level.id}-${solo.waveIndex}`, index: solo.questionCounter });
  solo.questionStartedAt = Date.now(); const durationMs = [0, 11000, 15000, 19000][questionDifficulty];
  setQuestionUI(solo.question, durationMs);
  solo.questionTimer = setTimeout(() => resolveSoloAnswer(null, null, true), durationMs);
}

function showFeedback(correct, title, detail) {
  elements.feedback.className = `feedback ${correct ? "correct" : "wrong"}`;
  elements.feedback.querySelector("strong").textContent = title; elements.feedback.querySelector("span").textContent = detail;
}

function resolveSoloAnswer(answer, index, timeout = false) {
  if (!solo?.active || solo.locked || solo.inTransition) return;
  solo.locked = true; clearTimeout(solo.questionTimer); elements.timeFill.classList.remove("active");
  elements.answers.forEach((button) => { button.disabled = true; if (Number(button.dataset.answer) === solo.question.answer) button.classList.add("correct"); });
  const correct = Number(answer) === solo.question.answer; const elapsedMs = Date.now() - solo.questionStartedAt; solo.answered += 1;
  if (index !== null && !correct) elements.answers[index].classList.add("wrong");
  if (correct) {
    solo.correct += 1; solo.combo += 1; solo.bestCombo = Math.max(solo.bestCombo, solo.combo);
    const attack = computeAttack({ difficulty: solo.question.difficulty, kind: solo.question.kind, combo: solo.combo, elapsedMs, upgrades: solo.upgrades });
    const kills = fireAttack(attack); const speedBonus = Math.max(0, Math.round((15000 - elapsedMs) / 130));
    solo.score += 90 * solo.question.difficulty + speedBonus + kills * 45 + solo.combo * 6;
    if (solo.level.objectiveTarget) solo.objective = clamp(solo.objective + [0, 9, 16, 27][solo.question.difficulty] + (solo.question.kind === "support" ? 5 : 0), 0, 100);
    showFeedback(true, `${attack.name}发射！`, `${kills ? `消灭 ${kills} 只魔鬼 · ` : "命中目标 · "}+${90 * solo.question.difficulty + speedBonus} 战斗分`); playTone("correct");
  } else {
    if (solo.upgrades.includes("comboGuard") && !solo.comboGuardUsed) { solo.comboGuardUsed = true; showBattleEffect("连击保险启动！", "success"); }
    else solo.combo = 0;
    const advance = 4 + solo.question.difficulty * 2;
    for (const enemy of solo.enemies.values()) enemy.progress = Math.min(99, enemy.progress + advance);
    showFeedback(false, timeout ? "武器充能超时" : "武器过热", solo.question.hint); playTone("wrong");
  }
  updateSoloHud();
  setTimeout(() => { if (!solo?.active || solo.inTransition) return; checkWaveComplete(); if (!solo.inTransition) renderSoloQuestion(); }, correct ? 760 : 1050);
}

function checkWaveComplete() {
  if (!solo?.active || solo.inTransition || solo.pendingSpawns > 0 || solo.enemies.size > 0) return;
  solo.inTransition = true; clearTimeout(solo.questionTimer); elements.timeFill.classList.remove("active");
  if (solo.waveIndex < 2) { setTimeout(offerUpgrades, 450); return; }
  if (solo.level.objectiveTarget && solo.objective < 100 && solo.bonusWaves < 2) {
    solo.bonusWaves += 1; setTimeout(() => { solo.inTransition = false; startWave(2, true); renderSoloQuestion(); }, 650); return;
  }
  setTimeout(() => finishSolo(true), 500);
}

function offerUpgrades() {
  if (!solo?.active) return;
  const rng = seededRandom(`upgrade-${solo.level.id}-${solo.waveIndex}-${solo.upgrades.length}`);
  const available = UPGRADE_CARDS
    .filter((card) => !solo.upgrades.includes(card.id))
    .map((card) => ({ card, order: rng() }))
    .sort((left, right) => left.order - right.order)
    .slice(0, 3)
    .map(({ card }) => card);
  elements.upgradeCards.innerHTML = available.map((card) => `<button data-upgrade="${card.id}"><span>${card.icon}</span><strong>${card.name}</strong><small>${card.description}</small></button>`).join("");
  elements.upgradeOverlay.classList.remove("hidden");
}

function chooseUpgrade(id) {
  if (!solo?.active || !solo.inTransition) return;
  const card = UPGRADE_CARDS.find((item) => item.id === id); if (!card) return;
  if (!solo.upgrades.includes(id)) solo.upgrades.push(id);
  if (id === "repair") solo.coreHealth = Math.min(100, solo.coreHealth + 15);
  elements.upgradeOverlay.classList.add("hidden"); showBattleEffect(`${card.name}已装备`, "success");
  solo.inTransition = false; startWave(solo.waveIndex + 1); renderSoloQuestion(); updateSoloHud(); playTone("select");
}

function finishSolo(success) {
  if (!solo?.active) return;
  solo.active = false; cleanupSolo(); const levelId = solo.level.id; const accuracy = solo.answered ? solo.correct / solo.answered : 0;
  const stars = success ? (solo.coreHealth >= 75 && accuracy >= .75 ? 3 : solo.coreHealth >= 35 ? 2 : 1) : 0;
  if (success) {
    campaign.stars[levelId] = Math.max(campaign.stars[levelId] || 0, stars);
    campaign.unlocked = Math.max(campaign.unlocked, Math.min(LEVELS.length, levelId + 1)); campaign.selectedLevel = Math.min(LEVELS.length, levelId + 1); persistCampaign();
  }
  elements.resultStars.textContent = stars ? `${"★ ".repeat(stars)}${"☆ ".repeat(3 - stars)}`.trim() : "☆ ☆ ☆";
  elements.resultKicker.textContent = success ? `${solo.level.missionName}完成` : "基地防线失守";
  elements.resultTitle.textContent = success ? (solo.level.mission === "boss" ? "魔王被击退了！" : "能量核心守住了！") : "重新组织火力吧";
  elements.resultScore.textContent = solo.score; elements.resultKills.textContent = solo.kills; elements.resultCombo.textContent = solo.bestCombo; elements.resultCore.textContent = `${Math.ceil(solo.coreHealth)}%`;
  elements.battleRanking.classList.add("hidden"); elements.playAgain.querySelector("strong").textContent = success && levelId < LEVELS.length ? "进入下一关" : success ? "再次挑战" : "重新挑战";
  lastResult = { type: "solo", levelId, success }; showScreen(elements.result); renderHome(); if (success) playTone("win");
}

function socketUrl() { return `${location.protocol === "https:" ? "wss:" : "ws:"}//${location.host}/ws`; }

function openBattle() {
  currentGame = null; elements.battleEntry.classList.remove("hidden"); elements.battleLobby.classList.add("hidden"); elements.battleError.textContent = ""; showScreen(elements.battle); connectBattle();
}

function connectBattle() {
  if (battle.socket?.readyState === WebSocket.OPEN) return Promise.resolve(battle.socket);
  if (battle.connecting) return battle.connecting;
  battle.connecting = new Promise((resolve, reject) => {
    const socket = new WebSocket(socketUrl()); battle.socket = socket; elements.networkStatus.className = "network-status"; elements.networkStatus.lastChild.textContent = "连接中";
    socket.addEventListener("open", () => { battle.connecting = null; elements.networkStatus.className = "network-status online"; elements.networkStatus.lastChild.textContent = "已连接"; resolve(socket); if (battle.token && !battle.playerId) socket.send(JSON.stringify({ type: "reconnect", token: battle.token })); });
    socket.addEventListener("message", (event) => handleBattleMessage(JSON.parse(event.data)));
    socket.addEventListener("close", () => { battle.connecting = null; elements.networkStatus.className = "network-status offline"; elements.networkStatus.lastChild.textContent = "连接中断"; });
    socket.addEventListener("error", () => reject(new Error("SOCKET_FAILED")));
  });
  return battle.connecting;
}

async function sendBattle(payload) {
  try { const socket = await connectBattle(); socket.send(JSON.stringify(payload)); }
  catch { elements.battleError.textContent = "暂时无法连接对战服务，请稍后重试"; }
}

function handleBattleMessage(message) {
  if (message.type === "room_created" || message.type === "room_joined") {
    battle.playerId = message.playerId; battle.token = message.token; battle.room = message.room; sessionStorage.setItem("arithmetic-battle-token", battle.token); showBattleLobby(); updateRoom(message.room);
  } else if (message.type === "reconnected") {
    battle.playerId = message.playerId; battle.room = message.room;
    if (["lobby", "countdown"].includes(message.room.status)) { showBattleLobby(); updateRoom(message.room); }
    else if (message.room.status === "playing") prepareBattleGame();
  } else if (message.type === "room_state") { battle.room = message.room; updateRoom(message.room); }
  else if (message.type === "countdown") { prepareBattleGame(); runCountdown(message.startsAt); }
  else if (message.type === "question") renderBattleQuestion(message);
  else if (message.type === "answer_ack") handleBattleAck(message);
  else if (message.type === "round_reveal") revealBattleRound(message);
  else if (message.type === "match_end") finishBattle(message);
  else if (message.type === "error") {
    if (message.code === "SESSION_NOT_FOUND") { battle.token = null; battle.playerId = null; sessionStorage.removeItem("arithmetic-battle-token"); }
    elements.battleError.textContent = message.message; toast(message.message);
  }
}

function showBattleLobby() { showScreen(elements.battle); elements.battleEntry.classList.add("hidden"); elements.battleLobby.classList.remove("hidden"); }

function updateRoom(room) {
  elements.roomCode.textContent = room.code.split("").join(" "); elements.waitingCopy.textContent = room.players.length < 2 ? "把房间码发给好友，等待对方加入" : "对手已加入，双方准备后立即开赛";
  elements.playerSlots.forEach((slot, index) => {
    const player = room.players[index]; slot.classList.toggle("ready", Boolean(player?.ready)); slot.querySelector(".slot-avatar").textContent = index === 0 ? "🚀" : player ? "😈" : "?";
    slot.querySelector("strong").textContent = player?.name || "等待玩家"; slot.querySelector("small").textContent = !player ? "未加入" : player.ready ? "已准备" : player.connected ? "未准备" : "连接中断";
  });
  const me = room.players.find((player) => player.id === battle.playerId);
  if (room.players.length < 2) { elements.ready.disabled = true; elements.ready.querySelector("strong").textContent = "等待好友加入"; }
  else if (me?.ready) { elements.ready.disabled = true; elements.ready.querySelector("strong").textContent = "已准备，等待对手"; }
  else { elements.ready.disabled = false; elements.ready.querySelector("strong").textContent = "准备守卫核心"; }
  if (currentGame === "battle") updateBattleHud(room.players);
}

function prepareBattleGame() {
  cleanupSolo(); solo = null; currentGame = "battle"; battle.locked = true; resetBattlefield(); elements.game.classList.add("battle-mode");
  elements.soloHud.classList.add("hidden"); elements.battleHud.classList.remove("hidden"); elements.difficultySelector.classList.add("hidden"); elements.tacticSelector.classList.remove("hidden"); elements.portalMeter.classList.remove("hidden");
  elements.objectiveWrap.classList.add("hidden"); elements.missionType.textContent = "实时攻防"; elements.missionTitle.textContent = "好友魔鬼攻防赛"; elements.targetTip.textContent = "连续答对3题，发动传送门战术";
  elements.expression.textContent = "双方正在进入战场"; elements.questionMeta.textContent = "同题同怪物波次"; elements.answers.forEach((button) => { button.disabled = true; button.querySelector("strong").textContent = "?"; });
  updateBattleHud(battle.room?.players || []); showScreen(elements.game);
}

function runCountdown(startsAt) {
  clearInterval(battle.countdownTimer); elements.countdown.classList.remove("hidden");
  const tick = () => { const remaining = Math.ceil((startsAt - Date.now()) / 1000); elements.countdown.querySelector("strong").textContent = remaining > 0 ? remaining : "GO"; if (remaining <= 0) { clearInterval(battle.countdownTimer); setTimeout(() => elements.countdown.classList.add("hidden"), 450); playTone("select"); } };
  tick(); battle.countdownTimer = setInterval(tick, 200);
}

function renderDuelEnemies(question) {
  elements.enemyLayer.innerHTML = ""; const count = [0, 2, 3, 5][question.difficulty];
  for (let index = 0; index < count; index += 1) {
    const type = index === count - 1 && question.difficulty >= 2 ? "shield" : index % 3 === 2 ? "bomber" : "imp";
    const node = document.createElement("div"); node.className = `enemy duel-enemy enemy-${type}`; node.style.left = `${[17, 50, 83][index % 3]}%`; node.style.top = `${8 + Math.floor(index / 3) * 18}%`; node.innerHTML = enemyMarkup({ type }); elements.enemyLayer.append(node);
  }
  elements.enemyCount.textContent = `魔鬼 ${count}`;
}

function renderBattleQuestion(message) {
  if (currentGame !== "battle") prepareBattleGame(); battle.question = message.question; battle.locked = false; elements.feedback.classList.add("hidden");
  renderDuelEnemies(message.question); setQuestionUI(message.question, message.durationMs, Math.max(0, Date.now() - message.startedAt));
  elements.battleRound.textContent = message.number; elements.missionTitle.textContent = `攻防波次 ${message.number} / ${message.total}`;
}

function chooseAnswer(index) {
  if (currentGame === "battle") {
    if (!battle.question || battle.locked) return; battle.locked = true; elements.answers.forEach((button) => { button.disabled = true; });
    sendBattle({ type: "answer", questionId: battle.question.id, answer: Number(elements.answers[index].dataset.answer), tactic: battle.tactic }); return;
  }
  if (!solo?.question || solo.locked) return; resolveSoloAnswer(Number(elements.answers[index].dataset.answer), index, false);
}

function handleBattleAck(message) {
  if (message.correct) {
    const enemies = [...elements.enemyLayer.querySelectorAll(".enemy")]; const removeCount = Math.min(enemies.length, message.reward?.kills || 1);
    enemies.slice(0, removeCount).forEach((node, index) => { setTimeout(() => { node.classList.add("defeated"); setTimeout(() => node.remove(), 300); }, index * 100); });
    animateProjectile(1, message.weapon?.id || "scatter");
    showFeedback(true, `${message.weapon?.name || "武器"}发射！`, `消灭 ${message.reward?.kills || 1} 只魔鬼 · 核心 ${message.coreHealth}`); playTone("correct");
    if (message.portal?.type === "raid") showBattleEffect(`传送偷袭！对手核心 -${message.portal.damage}`, "danger");
    if (message.portal?.type === "shield") showBattleEffect(`修复战术！核心 +${message.portal.restored}`, "success");
  } else {
    elements.energyCore.classList.add("hit"); setTimeout(() => elements.energyCore.classList.remove("hit"), 400);
    showFeedback(false, message.timeout ? "充能超时" : "魔鬼突破防线", `核心剩余 ${message.coreHealth}`); playTone("wrong");
  }
}

function revealBattleRound(message) {
  const index = battle.question?.choices.indexOf(message.correctAnswer); if (index >= 0) elements.answers[index].classList.add("correct"); updateBattleHud(message.players);
}

function updateBattleHud(players) {
  const me = players.find((player) => player.id === battle.playerId); const rival = players.find((player) => player.id !== battle.playerId);
  elements.myCore.textContent = me?.coreHealth ?? 100; elements.rivalCore.textContent = rival?.coreHealth ?? 100; elements.myKills.textContent = me?.kills || 0; elements.rivalKills.textContent = rival?.kills || 0;
  const energy = me?.portalEnergy || 0; elements.portalDots.textContent = `${"● ".repeat(energy)}${"○ ".repeat(3 - energy)}`.trim();
  elements.myCore.parentElement.classList.toggle("danger", (me?.coreHealth ?? 100) <= 30); elements.rivalCore.parentElement.classList.toggle("danger", (rival?.coreHealth ?? 100) <= 30);
}

function finishBattle(message) {
  elements.countdown.classList.add("hidden"); elements.timeFill.classList.remove("active"); const me = message.ranking.find((player) => player.id === battle.playerId); const won = message.winnerId === battle.playerId;
  elements.resultStars.textContent = won ? "★ ★ ★" : message.draw ? "★ ★ ☆" : "★ ☆ ☆"; elements.resultKicker.textContent = "好友攻防赛结束"; elements.resultTitle.textContent = message.draw ? "势均力敌！" : won ? "成功攻破对手防线！" : "基地失守，再战一次";
  elements.resultScore.textContent = me?.score || 0; elements.resultKills.textContent = me?.kills || 0; elements.resultCombo.textContent = me?.bestCombo || 0; elements.resultCore.textContent = `${me?.coreHealth ?? 0}%`;
  elements.battleRanking.innerHTML = message.ranking.map((player, index) => `<div class="ranking-row ${index === 0 && !message.draw ? "winner" : ""}"><span>${index + 1}</span><strong>${escapeHtml(player.name)}</strong><small>核心 ${player.coreHealth} · 击杀 ${player.kills}</small><b>${player.score}分</b></div>`).join("");
  elements.battleRanking.classList.remove("hidden"); elements.playAgain.querySelector("strong").textContent = "创建新对战"; lastResult = { type: "battle" };
  battle.socket?.close(); battle.socket = null; battle.token = null; battle.playerId = null; battle.room = null; sessionStorage.removeItem("arithmetic-battle-token"); showScreen(elements.result); if (won || message.draw) playTone("win");
}

function escapeHtml(value) { return String(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character])); }

function leaveCurrentGame() {
  cleanupSolo(); solo = null; clearInterval(battle.countdownTimer);
  if (currentGame === "battle" || battle.playerId || battle.socket) { battle.socket?.close(); battle.socket = null; battle.playerId = null; battle.token = null; battle.room = null; sessionStorage.removeItem("arithmetic-battle-token"); }
  currentGame = null; renderHome(); showScreen(elements.home);
}

elements.soundToggle.addEventListener("click", toggleSound); elements.gameSound.addEventListener("click", toggleSound);
elements.campaignStart.addEventListener("click", () => startSoloLevel(campaign.selectedLevel)); elements.levelOpen.addEventListener("click", openMap); elements.battleOpen.addEventListener("click", openBattle); elements.mapBack.addEventListener("click", () => { renderHome(); showScreen(elements.home); });
elements.chapterTabs.addEventListener("click", (event) => { const button = event.target.closest("[data-chapter]"); if (button) renderMap(Number(button.dataset.chapter)); });
elements.levelGrid.addEventListener("click", (event) => { const button = event.target.closest("[data-level]"); if (!button || button.disabled) return; campaign.selectedLevel = Number(button.dataset.level); persistCampaign(); startSoloLevel(campaign.selectedLevel); });
for (const button of $$('[data-back-home]')) button.addEventListener("click", leaveCurrentGame); elements.gameExit.addEventListener("click", leaveCurrentGame);
for (const button of elements.difficulties) button.addEventListener("click", () => setDifficulty(button.dataset.difficulty));
elements.answers.forEach((button, index) => button.addEventListener("click", () => chooseAnswer(index)));
elements.upgradeCards.addEventListener("click", (event) => { const button = event.target.closest("[data-upgrade]"); if (button) chooseUpgrade(button.dataset.upgrade); });
elements.tacticButtons.forEach((button) => button.addEventListener("click", () => { battle.tactic = button.dataset.tactic; elements.tacticButtons.forEach((item) => item.classList.toggle("active", item === button)); playTone("select"); }));

document.addEventListener("keydown", (event) => { if (!elements.game.classList.contains("active")) return; const index = { "1": 0, "2": 1, "3": 2 }[event.key]; if (index === undefined) return; event.preventDefault(); chooseAnswer(index); });

elements.createRoom.addEventListener("click", () => { elements.battleError.textContent = ""; sendBattle({ type: "create_room", player: { name: elements.playerName.value, avatar: "blue" } }); });
elements.joinRoom.addEventListener("click", () => { const code = elements.codeInput.value.trim().toUpperCase(); if (code.length !== 5) { elements.battleError.textContent = "请输入完整的5位房间码"; return; } elements.battleError.textContent = ""; sendBattle({ type: "join_room", code, player: { name: elements.playerName.value, avatar: "orange" } }); });
elements.codeInput.addEventListener("input", () => { elements.codeInput.value = elements.codeInput.value.replace(/[^a-zA-Z0-9]/g, "").toUpperCase().slice(0, 5); });
elements.copyCode.addEventListener("click", async () => { if (!battle.room?.code) return; try { await navigator.clipboard.writeText(battle.room.code); toast("房间码已复制，发给好友吧"); } catch { toast(`房间码：${battle.room.code}`); } });
elements.ready.addEventListener("click", () => { elements.ready.disabled = true; elements.ready.querySelector("strong").textContent = "已准备"; sendBattle({ type: "ready", ready: true, mode: "mixed" }); });
elements.playAgain.addEventListener("click", () => { if (lastResult.type === "battle") openBattle(); else startSoloLevel(lastResult.success ? Math.min(LEVELS.length, lastResult.levelId + 1) : lastResult.levelId); });
elements.resultMap.addEventListener("click", openMap); elements.resultHome.addEventListener("click", leaveCurrentGame);

updateSoundButtons(); renderHome();
