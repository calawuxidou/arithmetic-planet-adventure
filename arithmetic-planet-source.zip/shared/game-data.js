export const CHAPTERS = [
  { id: 1, name: "星港失守", color: "cyan", description: "夺回能量港，学会锁定目标与分裂弹。" },
  { id: 2, name: "黑暗矿车", color: "amber", description: "护送矿车穿越矿洞，用激光击穿魔盾。" },
  { id: 3, name: "迷雾沼泽", color: "green", description: "优先消灭治疗魔，救出被困的探险队。" },
  { id: 4, name: "齿轮魔城", color: "violet", description: "关闭传送门，组合强化卡突破机械军团。" },
  { id: 5, name: "魔王要塞", color: "red", description: "集结所有武器，挑战多阶段暗黑魔王。" }
];

const levelRows = [
  [1, "港口警报", "eliminate", "multiply", ["imp"], [4, 5, 6], "用乘法分裂弹清理第一批小恶魔"],
  [1, "三路围攻", "defense", "multiply", ["imp", "bomber"], [5, 6, 7], "判断最危险的路线并优先锁定"],
  [1, "炸药桶阵", "eliminate", "multiply", ["imp", "splitter"], [5, 7, 8], "利用范围攻击引爆成群敌人"],
  [1, "修复机器人", "rescue", "support", ["imp", "bomber"], [6, 7, 8], "完成救援题，为基地恢复能量"],
  [1, "岩石巨魔", "boss", "mixed", ["imp", "rockBoss"], [5, 7, 1], "击破三阶段魔盾，夺回星港"],
  [2, "矿洞入口", "eliminate", "divide", ["imp", "shield"], [5, 6, 7], "除法激光可以无视盾牌减伤"],
  [2, "矿车启动", "escort", "divide", ["imp", "shield"], [6, 7, 8], "答题为矿车充能并护送前进"],
  [2, "落石隧道", "survive", "divide", ["bomber", "shield"], [6, 8, 9], "在炸弹魔抵达前击穿它们"],
  [2, "分岔铁轨", "defense", "mixed", ["shield", "splitter"], [7, 8, 9], "在穿透与范围武器间快速切换"],
  [2, "吞矿魔王", "boss", "mixed", ["shield", "mineBoss"], [6, 8, 1], "保护矿车并攻击魔王弱点"],
  [3, "迷雾边缘", "eliminate", "mixed", ["imp", "healer"], [6, 7, 8], "治疗魔会持续恢复附近敌人"],
  [3, "失踪小队", "rescue", "support", ["healer", "bomber"], [6, 8, 9], "积累救援进度，救出探险队"],
  [3, "毒藤小径", "survive", "mixed", ["splitter", "healer"], [7, 8, 10], "用冰冻和爆炸阻止分裂怪群"],
  [3, "沼泽双桥", "escort", "mixed", ["shield", "healer", "splitter"], [7, 9, 10], "护送能量车通过两座断桥"],
  [3, "迷雾女巫", "boss", "mixed", ["healer", "witchBoss"], [7, 9, 1], "打断治疗法术并摧毁女巫魔核"],
  [4, "齿轮城门", "eliminate", "mixed", ["shield", "flyer"], [7, 9, 10], "飞行魔会突然切换攻击路线"],
  [4, "失控工厂", "defense", "mixed", ["bomber", "flyer", "shield"], [8, 10, 11], "同时处理装甲、飞行与爆炸威胁"],
  [4, "传送门群", "survive", "mixed", ["thief", "splitter", "flyer"], [8, 10, 12], "偷能魔会夺走尚未使用的技能能量"],
  [4, "核心熔炉", "escort", "mixed", ["shield", "thief", "bomber"], [9, 11, 12], "组合强化卡，把能量送入熔炉"],
  [4, "齿轮巨兽", "boss", "mixed", ["flyer", "gearBoss"], [8, 10, 1], "根据装甲阶段切换对应武器"],
  [5, "要塞外围", "eliminate", "mixed", ["healer", "shield", "bomber"], [9, 11, 12], "精英魔鬼开始协同进攻"],
  [5, "暗影回廊", "rescue", "mixed", ["thief", "flyer", "healer"], [9, 12, 13], "抢回被偷走的星核并救援伙伴"],
  [5, "四门封锁", "defense", "mixed", ["shield", "splitter", "thief", "bomber"], [10, 12, 14], "所有怪物能力同时出现"],
  [5, "王座之前", "survive", "mixed", ["flyer", "healer", "shield", "thief"], [10, 13, 15], "坚持到星核炸弹完成充能"],
  [5, "暗黑算术魔王", "boss", "mixed", ["shadowBoss"], [8, 10, 1], "终极三阶段决战：穿透、分裂与星核爆破"]
];

const missionNames = {
  eliminate: "歼灭战",
  defense: "基地防守",
  rescue: "救援任务",
  escort: "护送任务",
  survive: "生存战",
  boss: "首领战"
};

export const LEVELS = levelRows.map((row, index) => ({
  id: index + 1,
  chapter: row[0],
  name: row[1],
  mission: row[2],
  missionName: missionNames[row[2]],
  focus: row[3],
  enemyPool: row[4],
  waves: row[5],
  description: row[6],
  coreHealth: row[2] === "defense" ? 85 : 100,
  objectiveTarget: ["escort", "rescue"].includes(row[2]) ? 100 : 0
}));

export const ENEMY_TYPES = {
  imp: { name: "小恶魔", health: 34, speed: 6.4, coreDamage: 9, threat: 1 },
  shield: { name: "盾牌魔", health: 82, speed: 3.7, coreDamage: 15, threat: 2, armor: 0.48 },
  healer: { name: "治疗魔", health: 54, speed: 4.4, coreDamage: 10, threat: 4, heals: true },
  splitter: { name: "分裂魔", health: 48, speed: 5.2, coreDamage: 10, threat: 2, splits: true },
  bomber: { name: "炸弹魔", health: 44, speed: 7.1, coreDamage: 24, threat: 5 },
  flyer: { name: "飞行魔", health: 42, speed: 7.5, coreDamage: 12, threat: 3, switchesLane: true },
  thief: { name: "偷能魔", health: 58, speed: 5.7, coreDamage: 13, threat: 4, steals: true },
  rockBoss: { name: "岩石巨魔", health: 430, speed: 1.05, coreDamage: 100, threat: 9, boss: true },
  mineBoss: { name: "吞矿魔王", health: 520, speed: 0.95, coreDamage: 100, threat: 9, boss: true },
  witchBoss: { name: "迷雾女巫", health: 580, speed: 0.9, coreDamage: 100, threat: 9, boss: true, heals: true },
  gearBoss: { name: "齿轮巨兽", health: 680, speed: 0.82, coreDamage: 100, threat: 9, boss: true, armor: 0.25 },
  shadowBoss: { name: "暗黑算术魔王", health: 820, speed: 0.72, coreDamage: 100, threat: 10, boss: true }
};

export const UPGRADE_CARDS = [
  { id: "damage", icon: "⬆", name: "能量增幅", description: "所有武器伤害提高25%" },
  { id: "ricochet", icon: "↗", name: "弹射弹头", description: "分裂弹额外攻击1个目标" },
  { id: "pierce", icon: "⇢", name: "超导透镜", description: "激光额外穿透1名敌人" },
  { id: "frost", icon: "❄", name: "寒冰核心", description: "每次命中使敌人短暂减速" },
  { id: "blast", icon: "✹", name: "扩容弹仓", description: "火箭爆炸范围扩大" },
  { id: "repair", icon: "♥", name: "修复无人机", description: "立即恢复15点基地生命" },
  { id: "comboGuard", icon: "◆", name: "连击保险", description: "每波可免除1次连击中断" },
  { id: "killHeal", icon: "+", name: "回收装置", description: "每消灭3名敌人恢复2点生命" },
  { id: "drone", icon: "◉", name: "战斗无人机", description: "每连对3题发动一次追踪攻击" },
  { id: "critical", icon: "⚡", name: "极速扳机", description: "5秒内答对时造成1.5倍伤害" }
];

export const WEAPONS = {
  multiply: { id: "scatter", name: "分裂弹", icon: "✦" },
  divide: { id: "laser", name: "穿透激光", icon: "⌁" },
  support: { id: "frost", name: "冰冻修复弹", icon: "❄" },
  mixed: { id: "rocket", name: "星核火箭", icon: "☄" }
};

export function bossWeakness(enemy) {
  if (!enemy?.boss) return null;
  const ratio = enemy.health / enemy.maxHealth;
  if (ratio > 0.67) return "divide";
  if (ratio > 0.34) return "multiply";
  return "mixed";
}

export function computeAttack({ difficulty = 1, kind = "multiply", combo = 0, elapsedMs = 9999, upgrades = [] } = {}) {
  const rank = Math.max(1, Math.min(3, Number(difficulty) || 1));
  const weapon = WEAPONS[kind] || WEAPONS.mixed;
  const owned = new Set(upgrades);
  let damage = [0, 38, 72, 132][rank];
  if (owned.has("damage")) damage *= 1.25;
  const critical = elapsedMs <= 5000 && owned.has("critical");
  if (critical) damage *= 1.5;
  damage *= 1 + Math.min(combo, 8) * 0.025;

  return {
    ...weapon,
    kind,
    difficulty: rank,
    damage: Math.round(damage),
    projectiles: kind === "multiply" ? rank + (owned.has("ricochet") ? 1 : 0) : 1,
    pierce: kind === "divide" ? rank + (owned.has("pierce") ? 1 : 0) : 1,
    splash: kind === "mixed" ? rank - 1 + (owned.has("blast") ? 1 : 0) : 0,
    freezeMs: kind === "support" ? 1300 + rank * 650 : owned.has("frost") ? 700 : 0,
    heal: kind === "support" ? 2 + rank * 3 : 0,
    critical
  };
}

export function difficultyReward(difficulty = 1) {
  const rank = Math.max(1, Math.min(3, Number(difficulty) || 1));
  return {
    kills: [0, 1, 2, 4][rank],
    score: [0, 110, 240, 420][rank],
    missDamage: [0, 7, 10, 14][rank]
  };
}
