import { spawn } from "node:child_process";
import { setTimeout as delay } from "node:timers/promises";
import { WebSocket } from "ws";

const port = 3187;
const base = `http://127.0.0.1:${port}`;
const child = spawn(process.execPath, ["server/index.js"], {
  cwd: new URL("..", import.meta.url),
  env: {
    ...process.env,
    PORT: String(port),
    COUNTDOWN_MS: "5",
    REVEAL_MS: "5",
    QUESTION_DURATION_MS: "1000"
  },
  stdio: ["ignore", "pipe", "pipe"]
});

const waitForServer = async () => {
  for (let attempt = 0; attempt < 30; attempt += 1) {
    try {
      const response = await fetch(`${base}/health`);
      if (response.ok) return;
    } catch {
      await delay(50);
    }
  }
  throw new Error("Server did not become healthy");
};

const openSocket = () => new Promise((resolve, reject) => {
  const socket = new WebSocket(`ws://127.0.0.1:${port}/ws`);
  socket.once("open", () => resolve(socket));
  socket.once("error", reject);
});

const nextMessage = (socket, type) => new Promise((resolve, reject) => {
  const timeout = setTimeout(() => reject(new Error(`Timed out waiting for ${type}`)), 5000);
  const listener = (raw) => {
    const message = JSON.parse(String(raw));
    if (message.type !== type) return;
    clearTimeout(timeout);
    socket.off("message", listener);
    resolve(message);
  };
  socket.on("message", listener);
});

try {
  await waitForServer();
  const [home, asset] = await Promise.all([fetch(`${base}/`), fetch(`${base}/assets/robot.webp`)]);
  if (!home.ok || !(await home.text()).includes("算术星球大冒险")) throw new Error("Home page failed");
  if (!asset.ok || !asset.headers.get("content-type")?.includes("image/webp")) throw new Error("Game asset failed");

  const host = await openSocket();
  host.send(JSON.stringify({ type: "create_room", player: { name: "队长" } }));
  const created = await nextMessage(host, "room_created");

  const guest = await openSocket();
  guest.send(JSON.stringify({ type: "join_room", code: created.room.code, player: { name: "挑战者" } }));
  await nextMessage(guest, "room_joined");

  let questions = 0;
  const play = (socket) => {
    socket.on("message", (raw) => {
      const message = JSON.parse(String(raw));
      if (message.type === "question") {
        if (socket === host) questions += 1;
        socket.send(JSON.stringify({
          type: "answer",
          questionId: message.question.id,
          answer: message.question.choices[0]
        }));
      }
    });
  };
  play(host);
  play(guest);

  host.send(JSON.stringify({ type: "ready", ready: true, mode: "mixed" }));
  guest.send(JSON.stringify({ type: "ready", ready: true, mode: "mixed" }));
  const finished = await nextMessage(host, "match_end");
  if (questions !== 10 || finished.ranking.length !== 2) throw new Error("Battle did not finish correctly");
  host.close();
  guest.close();
  console.log("Smoke test passed: HTTP, assets and 10-round WebSocket battle are healthy.");
} finally {
  child.kill("SIGTERM");
}
