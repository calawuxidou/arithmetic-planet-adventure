import express from "express";
import { createServer } from "node:http";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { WebSocket, WebSocketServer } from "ws";
import { RoomManager } from "./room-manager.js";
import { publicQuestion } from "../shared/questions.js";

const currentFile = fileURLToPath(import.meta.url);
const root = path.resolve(path.dirname(currentFile), "..");
const distRoot = path.join(root, "dist");
const publicRoot = existsSync(path.join(distRoot, "index.html")) ? distRoot : path.join(root, "public");
const port = Number(process.env.PORT || 3000);

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "32kb" }));
app.get("/health", (_request, response) => response.json({ ok: true, service: "arithmetic-planet" }));
app.use(express.static(publicRoot, { extensions: ["html"] }));
if (publicRoot.endsWith("public")) app.use("/shared", express.static(path.join(root, "shared")));
app.use((request, response, next) => {
  if (request.method !== "GET" || request.path.startsWith("/ws")) return next();
  return response.sendFile(path.join(publicRoot, "index.html"));
});

const server = createServer(app);
const sockets = new Map();

function send(socket, payload) {
  if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(payload));
}

const rooms = new RoomManager({
  questionDurationMs: Number(process.env.QUESTION_DURATION_MS || 9000),
  countdownMs: Number(process.env.COUNTDOWN_MS || 3000),
  revealMs: Number(process.env.REVEAL_MS || 1100),
  broadcast(room, payload) {
    for (const player of room.players) send(sockets.get(player.id), payload);
  },
  direct(playerId, payload) {
    send(sockets.get(playerId), payload);
  }
});

const wss = new WebSocketServer({ server, path: "/ws", maxPayload: 32 * 1024 });
wss.on("connection", (socket) => {
  let playerId = null;
  socket.isAlive = true;
  socket.on("pong", () => { socket.isAlive = true; });

  socket.on("message", (raw) => {
    let message;
    try {
      message = JSON.parse(String(raw));
    } catch {
      send(socket, { type: "error", code: "INVALID_MESSAGE", message: "消息格式不正确" });
      return;
    }

    try {
      if (message.type === "create_room") {
        const result = rooms.createRoom(message.player);
        playerId = result.player.id;
        sockets.set(playerId, socket);
        send(socket, {
          type: "room_created",
          playerId,
          token: result.player.token,
          room: rooms.getSnapshot(result.room)
        });
      } else if (message.type === "join_room") {
        const result = rooms.joinRoom(message.code, message.player);
        playerId = result.player.id;
        sockets.set(playerId, socket);
        send(socket, {
          type: "room_joined",
          playerId,
          token: result.player.token,
          room: rooms.getSnapshot(result.room)
        });
      } else if (message.type === "reconnect") {
        const result = rooms.reconnect(message.token);
        playerId = result.player.id;
        sockets.set(playerId, socket);
        send(socket, { type: "reconnected", playerId, room: rooms.getSnapshot(result.room) });
        if (result.room.status === "playing" && result.room.questionIndex >= 0) {
          const question = result.room.questions[result.room.questionIndex];
          send(socket, {
            type: "question",
            question: publicQuestion(question),
            number: result.room.questionIndex + 1,
            total: result.room.questions.length,
            startedAt: result.room.questionStartedAt,
            durationMs: rooms.questionDurationMs
          });
        }
      } else if (message.type === "ready") {
        if (!playerId) throw new Error("SESSION_REQUIRED");
        rooms.setReady(playerId, message.ready, message.mode);
      } else if (message.type === "answer") {
        if (!playerId) throw new Error("SESSION_REQUIRED");
        rooms.submitAnswer(playerId, message);
      } else if (message.type === "ping") {
        send(socket, { type: "pong", at: Date.now() });
      } else {
        throw new Error("UNKNOWN_ACTION");
      }
    } catch (error) {
      const messages = {
        ROOM_NOT_FOUND: "没有找到这个房间",
        ROOM_FULL: "房间已经满员",
        MATCH_ALREADY_STARTED: "对战已经开始",
        MATCH_NOT_PLAYING: "比赛还没有开始",
        QUESTION_EXPIRED: "这道题已经结束",
        ALREADY_ANSWERED: "本题已经作答",
        SESSION_NOT_FOUND: "房间连接已失效，请重新进入",
        SESSION_REQUIRED: "请先进入房间",
        UNKNOWN_ACTION: "暂不支持这个操作"
      };
      send(socket, { type: "error", code: error.message, message: messages[error.message] || "操作失败，请重试" });
    }
  });

  socket.on("close", () => {
    if (!playerId) return;
    if (sockets.get(playerId) === socket) sockets.delete(playerId);
    rooms.disconnect(playerId);
  });
});

const heartbeat = setInterval(() => {
  for (const socket of wss.clients) {
    if (!socket.isAlive) {
      socket.terminate();
      continue;
    }
    socket.isAlive = false;
    socket.ping();
  }
}, 25000);

server.on("close", () => {
  clearInterval(heartbeat);
  rooms.dispose();
});

server.listen(port, "0.0.0.0", () => {
  console.log(`算术星球大冒险已启动：http://localhost:${port}`);
});
