import { randomBytes, randomUUID } from "node:crypto";
import { createQuestionSet, publicQuestion, checkAnswer } from "../shared/questions.js";

const ROOM_ALPHABET = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";

function roomCode() {
  const bytes = randomBytes(5);
  return Array.from(bytes, (byte) => ROOM_ALPHABET[byte % ROOM_ALPHABET.length]).join("");
}

function cleanName(value) {
  const name = String(value || "小小宇航员").replace(/[<>]/g, "").trim().slice(0, 10);
  return name || "小小宇航员";
}

function playerView(player) {
  return {
    id: player.id,
    name: player.name,
    avatar: player.avatar,
    score: player.score,
    correct: player.correct,
    combo: player.combo,
    bestCombo: player.bestCombo,
    answered: player.answered,
    totalResponseMs: player.totalResponseMs,
    ready: player.ready,
    connected: player.connected
  };
}

export class RoomManager {
  constructor({ broadcast = () => {}, direct = () => {}, questionDurationMs = 15000, countdownMs = 3000, revealMs = 1100 } = {}) {
    this.rooms = new Map();
    this.sessions = new Map();
    this.broadcast = broadcast;
    this.direct = direct;
    this.questionDurationMs = questionDurationMs;
    this.countdownMs = countdownMs;
    this.revealMs = revealMs;
  }

  createRoom({ name, avatar = "blue" } = {}) {
    let code = roomCode();
    while (this.rooms.has(code)) code = roomCode();

    const player = this.#makePlayer({ name, avatar });
    const room = {
      code,
      hostId: player.id,
      status: "lobby",
      mode: "mixed",
      players: [player],
      questions: [],
      questionIndex: -1,
      questionStartedAt: 0,
      answers: new Map(),
      timers: new Set(),
      createdAt: Date.now()
    };
    this.rooms.set(code, room);
    this.sessions.set(player.token, { code, playerId: player.id });
    return { room, player };
  }

  joinRoom(code, { name, avatar = "orange" } = {}) {
    const normalized = String(code || "").trim().toUpperCase();
    const room = this.rooms.get(normalized);
    if (!room) throw new Error("ROOM_NOT_FOUND");
    if (room.status !== "lobby") throw new Error("MATCH_ALREADY_STARTED");
    if (room.players.length >= 2) throw new Error("ROOM_FULL");

    const player = this.#makePlayer({ name, avatar });
    room.players.push(player);
    this.sessions.set(player.token, { code: room.code, playerId: player.id });
    this.#emitState(room);
    return { room, player };
  }

  reconnect(token) {
    const session = this.sessions.get(token);
    if (!session) throw new Error("SESSION_NOT_FOUND");
    const room = this.rooms.get(session.code);
    const player = room?.players.find((item) => item.id === session.playerId);
    if (!room || !player) throw new Error("SESSION_NOT_FOUND");
    player.connected = true;
    this.#emitState(room);
    return { room, player };
  }

  disconnect(playerId) {
    const room = this.findRoomByPlayer(playerId);
    const player = room?.players.find((item) => item.id === playerId);
    if (!room || !player) return;
    player.connected = false;
    this.#emitState(room);

    const timer = setTimeout(() => {
      room.timers.delete(timer);
      if (player.connected) return;
      if (room.status === "lobby") {
        room.players = room.players.filter((item) => item.id !== playerId);
        this.sessions.delete(player.token);
        if (room.players.length === 0) this.deleteRoom(room.code);
        else {
          if (room.hostId === playerId) room.hostId = room.players[0].id;
          this.#emitState(room);
        }
      }
    }, 30000);
    room.timers.add(timer);
  }

  setReady(playerId, ready = true, mode = "mixed") {
    const room = this.#requireRoomForPlayer(playerId);
    if (room.status !== "lobby") throw new Error("MATCH_ALREADY_STARTED");
    const player = room.players.find((item) => item.id === playerId);
    player.ready = Boolean(ready);
    if (playerId === room.hostId) room.mode = mode === "muldiv" ? "muldiv" : "mixed";
    this.#emitState(room);

    if (room.players.length === 2 && room.players.every((item) => item.ready && item.connected)) {
      this.#beginCountdown(room);
    }
    return room;
  }

  submitAnswer(playerId, { questionId, answer }) {
    const room = this.#requireRoomForPlayer(playerId);
    if (room.status !== "playing") throw new Error("MATCH_NOT_PLAYING");
    const question = room.questions[room.questionIndex];
    if (!question || question.id !== questionId) throw new Error("QUESTION_EXPIRED");
    if (room.answers.has(playerId)) throw new Error("ALREADY_ANSWERED");

    const player = room.players.find((item) => item.id === playerId);
    const responseMs = Math.max(0, Date.now() - room.questionStartedAt);
    const correct = checkAnswer(question, answer);
    player.answered += 1;
    player.totalResponseMs += responseMs;
    if (correct) {
      player.correct += 1;
      player.combo += 1;
      player.bestCombo = Math.max(player.bestCombo, player.combo);
      const speedBonus = Math.max(0, Math.floor((this.questionDurationMs - responseMs) / 300));
      player.score += 100 + speedBonus + Math.min(player.combo, 5) * 8;
    } else {
      player.combo = 0;
    }

    room.answers.set(playerId, { answer: Number(answer), correct, responseMs });
    this.direct(playerId, {
      type: "answer_ack",
      correct,
      score: player.score,
      combo: player.combo,
      responseMs
    });
    this.#emitState(room);

    if (room.answers.size >= room.players.length) this.#revealAndAdvance(room);
    return { correct, score: player.score };
  }

  getSnapshot(room) {
    return {
      code: room.code,
      hostId: room.hostId,
      status: room.status,
      mode: room.mode,
      players: room.players.map(playerView),
      questionIndex: room.questionIndex,
      totalQuestions: room.questions.length
    };
  }

  findRoomByPlayer(playerId) {
    for (const room of this.rooms.values()) {
      if (room.players.some((player) => player.id === playerId)) return room;
    }
    return null;
  }

  deleteRoom(code) {
    const room = this.rooms.get(code);
    if (!room) return;
    for (const timer of room.timers) clearTimeout(timer);
    for (const player of room.players) this.sessions.delete(player.token);
    this.rooms.delete(code);
  }

  dispose() {
    for (const room of this.rooms.values()) this.deleteRoom(room.code);
  }

  #makePlayer({ name, avatar }) {
    return {
      id: randomUUID(),
      token: randomBytes(24).toString("hex"),
      name: cleanName(name),
      avatar: avatar === "orange" ? "orange" : "blue",
      score: 0,
      correct: 0,
      combo: 0,
      bestCombo: 0,
      answered: 0,
      totalResponseMs: 0,
      ready: false,
      connected: true
    };
  }

  #requireRoomForPlayer(playerId) {
    const room = this.findRoomByPlayer(playerId);
    if (!room) throw new Error("ROOM_NOT_FOUND");
    return room;
  }

  #emitState(room) {
    this.broadcast(room, { type: "room_state", room: this.getSnapshot(room) });
  }

  #beginCountdown(room) {
    if (room.status !== "lobby") return;
    room.status = "countdown";
    const startsAt = Date.now() + this.countdownMs;
    this.broadcast(room, { type: "countdown", startsAt });
    this.#emitState(room);
    const timer = setTimeout(() => {
      room.timers.delete(timer);
      this.#startMatch(room);
    }, this.countdownMs);
    room.timers.add(timer);
  }

  #startMatch(room) {
    room.status = "playing";
    const seed = `${room.code}-${room.createdAt}`;
    room.questions = createQuestionSet({ mode: room.mode, count: 10, seed });
    room.questionIndex = -1;
    for (const player of room.players) {
      player.score = 0;
      player.correct = 0;
      player.combo = 0;
      player.bestCombo = 0;
      player.answered = 0;
      player.totalResponseMs = 0;
    }
    this.#nextQuestion(room);
  }

  #nextQuestion(room) {
    if (room.status !== "playing") return;
    room.questionIndex += 1;
    room.answers = new Map();
    if (room.questionIndex >= room.questions.length) {
      this.#finishMatch(room);
      return;
    }

    room.questionStartedAt = Date.now();
    const question = room.questions[room.questionIndex];
    this.broadcast(room, {
      type: "question",
      question: publicQuestion(question),
      number: room.questionIndex + 1,
      total: room.questions.length,
      startedAt: room.questionStartedAt,
      durationMs: this.questionDurationMs
    });
    this.#emitState(room);

    const timer = setTimeout(() => {
      room.timers.delete(timer);
      if (room.status !== "playing" || room.questions[room.questionIndex]?.id !== question.id) return;
      for (const player of room.players) {
        if (!room.answers.has(player.id)) {
          player.answered += 1;
          player.combo = 0;
          player.totalResponseMs += this.questionDurationMs;
          room.answers.set(player.id, { answer: null, correct: false, responseMs: this.questionDurationMs });
          this.direct(player.id, { type: "answer_ack", correct: false, timeout: true, score: player.score, combo: 0 });
        }
      }
      this.#revealAndAdvance(room);
    }, this.questionDurationMs);
    room.questionTimer = timer;
    room.timers.add(timer);
  }

  #revealAndAdvance(room) {
    if (room.revealing) return;
    room.revealing = true;
    if (room.questionTimer) {
      clearTimeout(room.questionTimer);
      room.timers.delete(room.questionTimer);
      room.questionTimer = null;
    }
    const question = room.questions[room.questionIndex];
    this.broadcast(room, {
      type: "round_reveal",
      correctAnswer: question.answer,
      hint: question.hint,
      players: room.players.map(playerView)
    });
    const timer = setTimeout(() => {
      room.timers.delete(timer);
      room.revealing = false;
      this.#nextQuestion(room);
    }, this.revealMs);
    room.timers.add(timer);
  }

  #finishMatch(room) {
    room.status = "finished";
    const ranking = [...room.players].sort((left, right) => {
      if (right.score !== left.score) return right.score - left.score;
      if (right.correct !== left.correct) return right.correct - left.correct;
      return left.totalResponseMs - right.totalResponseMs;
    });
    const draw = ranking.length === 2 && ranking[0].score === ranking[1].score && ranking[0].correct === ranking[1].correct && ranking[0].totalResponseMs === ranking[1].totalResponseMs;
    this.broadcast(room, {
      type: "match_end",
      winnerId: draw ? null : ranking[0]?.id || null,
      draw,
      ranking: ranking.map(playerView),
      room: this.getSnapshot(room)
    });
    this.#emitState(room);
  }
}
