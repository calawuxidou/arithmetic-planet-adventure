import { createQuestionSet } from "/shared/questions.js";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const elements = {
  screens: $$(".screen"),
  home: $("#screen-home"),
  battle: $("#screen-battle"),
  game: $("#screen-game"),
  result: $("#screen-result"),
  soundToggle: $("#sound-toggle"),
  gameSound: $("#game-sound"),
  soloStart: $("#solo-start"),
  battleOpen: $("#battle-open"),
  battleEntry: $("#battle-entry"),
  battleLobby: $("#battle-lobby"),
  playerName: $("#player-name"),
  codeInput: $("#room-code-input"),
  createRoom: $("#create-room"),
  joinRoom: $("#join-room"),
  battleError: $("#battle-error"),
  networkStatus: $("#network-status"),
  roomCode: $("#room-code"),
  copyCode: $("#copy-code"),
  waitingCopy: $("#waiting-copy"),
  ready: $("#ready-button"),
  playerSlots: [$("#player-one"), $("#player-two")],
  soloHud: $("#solo-hud"),
  battleHud: $("#battle-hud"),
  hearts: $("#hearts-display"),
  energy: $("#energy-display"),
  score: $("#score-display"),
  myScore: $("#my-score"),
  rivalScore: $("#rival-score"),
  battleRound: $("#battle-round"),
  gameExit: $("#game-exit"),
  world: $("#game-world"),
  progress: $("#progress-fill"),
  questionProgress: $("#question-progress"),
  sceneLabel: $("#scene-label"),
  expression: $("#expression"),
  timeFill: $("#time-fill"),
  gates: $$(".answer-gate"),
  runner: $("#runner"),
  opponent: $("#opponent-runner"),
  feedback: $("#feedback"),
  combo: $("#combo-badge"),
  bossZone: $("#boss-zone"),
  bossHealth: $("#boss-health-fill"),
  countdown: $("#countdown-overlay"),
  resultStars: $("#result-stars"),
  resultKicker: $("#result-kicker"),
  resultTitle: $("#result-title"),
  resultScore: $("#result-score"),
  resultCorrect: $("#result-correct"),
  resultCombo: $("#result-combo"),
  resultCrystals: $("#result-crystals"),
  battleRanking: $("#battle-ranking"),
  playAgain: $("#play-again"),
  resultHome: $("#result-home"),
  toast: $("#toast")
};

let selectedMode = "mixed";
let soundEnabled = localStorage.getItem("arithmetic-sound") !== "off";
let audioContext = null;
let currentGame = null;
let solo = null;
let soloTimer = null;
let lastResult = { type: "solo", wrongQuestions: [] };
let toastTimer = null;

const battle = {
  socket: null,
  connecting: null,
  playerId: null,
  token: sessionStorage.getItem("arithmetic-battle-token"),
  room: null,
  question: null,
  locked: false,
  selectedLane: 1,
  countdownTimer: null
};

function showScreen(target) {
  for (const screen of elements.screens) screen.classList.toggle("active", screen === target);
  window.scrollTo({ top: 0, behavior: "instant" });
}

function updateSoundButtons() {
  const symbol = soundEnabled ? "♫" : "♪";
  elements.soundToggle.textContent = symbol;
  elements.gameSound.textContent = symbol;
  elements.soundToggle.setAttribute("aria-label", soundEnabled ? "关闭音效" : "开启音效");
  elements.gameSound.setAttribute("aria-label", soundEnabled ? "关闭音效" : "开启音效");
}

function toggleSound() {
  soundEnabled = !soundEnabled;
  localStorage.setItem("arithmetic-sound", soundEnabled ? "on" : "off");
  updateSoundButtons();
  if (soundEnabled) playTone("select");
}

function playTone(kind) {
  if (!soundEnabled) return;
  try {
    audioContext ||= new AudioContext();
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    const settings = {
      select: [420, .06, "sine"],
      correct: [720, .13, "triangle"],
      wrong: [180, .18, "sawtooth"],
      start: [520, .18, "square"],
      win: [880, .28, "triangle"]
    }[kind] || [400, .08, "sine"];
    oscillator.type = settings[2];
    oscillator.frequency.setValueAtTime(settings[0], audioContext.currentTime);
    if (kind === "correct" || kind === "win") oscillator.frequency.exponentialRampToValueAtTime(settings[0] * 1.45, audioContext.currentTime + settings[1]);
    gain.gain.setValueAtTime(.055, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + settings[1]);
    oscillator.connect(gain).connect(audioContext.destination);
    oscillator.start();
    oscillator.stop(audioContext.currentTime + settings[1]);
  } catch {
    // Sound is decorative; gameplay remains available when audio is blocked.
  }
}

function toast(message) {
  clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.add("show");
  toastTimer = setTimeout(() => elements.toast.classList.remove("show"), 1800);
}

function setMode(mode) {
  selectedMode = mode === "muldiv" ? "muldiv" : "mixed";
  for (const chip of $$(".mode-chip")) {
    const active = chip.dataset.mode === selectedMode;
    chip.classList.toggle("active", active);
    chip.setAttribute("aria-checked", String(active));
  }
  playTone("select");
}

function moveRunner(lane, commit = false) {
  for (let index = 0; index < 3; index += 1) {
    elements.runner.classList.toggle(`lane-${index}`, index === lane);
    elements.gates[index].classList.toggle("selected", index === lane);
  }
  elements.runner.classList.toggle("commit", commit);
}

function setGates(choices) {
  elements.gates.forEach((gate, index) => {
    gate.disabled = false;
    gate.classList.remove("correct", "wrong", "selected");
    gate.querySelector("strong").textContent = choices[index];
    gate.dataset.answer = choices[index];
  });
  moveRunner(1, false);
}

function setQuestionTimer(seconds = 18, elapsedMs = 0) {
  elements.timeFill.classList.remove("active");
  elements.timeFill.style.width = "100%";
  elements.timeFill.style.setProperty("--question-time", `${Math.max(350, seconds * 1000 - elapsedMs)}ms`);
  void elements.timeFill.offsetWidth;
  elements.timeFill.classList.add("active");
}

function setBossStage(active, progress = 0) {
  elements.bossZone.classList.toggle("hidden", !active);
  elements.world.classList.toggle("boss-active", active);
  if (active) elements.bossHealth.style.width = `${Math.max(0, 100 - progress * 34)}%`;
}

function showFeedback(correct, title, detail) {
  elements.feedback.classList.remove("hidden", "wrong");
  elements.feedback.classList.toggle("wrong", !correct);
  elements.feedback.querySelector("strong").textContent = title;
  elements.feedback.querySelector("span").textContent = detail;
}

function hideFeedback() {
  elements.feedback.classList.add("hidden");
  elements.feedback.classList.remove("wrong");
}

function disableGates() {
  for (const gate of elements.gates) gate.disabled = true;
}

function startSolo({ repairQuestions = null } = {}) {
  clearTimeout(soloTimer);
  currentGame = "solo";
  const questions = repairQuestions?.length
    ? repairQuestions
    : createQuestionSet({ mode: selectedMode, count: 10, seed: `${Date.now()}-${Math.random()}` });
  solo = {
    questions,
    index: 0,
    score: 0,
    hearts: 3,
    energy: 0,
    combo: 0,
    bestCombo: 0,
    correct: 0,
    crystals: 0,
    wrongQuestions: [],
    locked: false,
    questionStartedAt: 0,
    rescueUsed: false,
    repair: Boolean(repairQuestions?.length)
  };
  elements.soloHud.classList.remove("hidden");
  elements.battleHud.classList.add("hidden");
  elements.opponent.classList.add("hidden");
  elements.battleRanking.classList.add("hidden");
  showScreen(elements.game);
  playTone("start");
  renderSoloQuestion();
}

function renderSoloQuestion() {
  const question = solo.questions[solo.index];
  if (!question) {
    finishSolo(true);
    return;
  }
  solo.locked = false;
  solo.questionStartedAt = Date.now();
  hideFeedback();
  elements.runner.classList.remove("commit");
  elements.world.classList.remove("running");
  elements.expression.textContent = question.expression;
  elements.questionProgress.textContent = `${solo.index + 1} / ${solo.questions.length}`;
  elements.progress.style.width = `${(solo.index / solo.questions.length) * 100}%`;
  elements.sceneLabel.textContent = solo.index >= solo.questions.length - 3
    ? "机械守卫 · BOSS战"
    : solo.index % 2 === 0 ? "传送门冲刺" : "能量桥修复";
  setBossStage(solo.index >= solo.questions.length - 3, solo.index - (solo.questions.length - 3));
  setGates(question.choices);
  setQuestionTimer(18);
  updateSoloHud();
  clearTimeout(soloTimer);
  soloTimer = setTimeout(() => resolveSoloAnswer(null, null), 18000);
}

function updateSoloHud() {
  elements.hearts.textContent = Array.from({ length: 3 }, (_, index) => index < solo.hearts ? "♥" : "♡").join(" ");
  elements.energy.textContent = `${Math.min(solo.energy, 5)}/5`;
  elements.score.textContent = solo.score;
  if (solo.combo >= 3) {
    elements.combo.classList.remove("hidden");
    elements.combo.querySelector("b").textContent = solo.combo;
  } else {
    elements.combo.classList.add("hidden");
  }
}

function chooseSoloLane(lane) {
  if (!solo || solo.locked) return;
  moveRunner(lane, false);
  playTone("select");
  setTimeout(() => {
    if (!solo || solo.locked) return;
    moveRunner(lane, true);
    elements.world.classList.add("running");
    resolveSoloAnswer(Number(elements.gates[lane].dataset.answer), lane);
  }, 170);
}

function resolveSoloAnswer(answer, lane) {
  if (!solo || solo.locked) return;
  solo.locked = true;
  clearTimeout(soloTimer);
  elements.timeFill.classList.remove("active");
  disableGates();
  const question = solo.questions[solo.index];
  const correct = answer === question.answer;
  const elapsed = Date.now() - solo.questionStartedAt;
  const correctLane = question.choices.indexOf(question.answer);

  elements.gates[correctLane].classList.add("correct");
  if (lane !== null && !correct) elements.gates[lane].classList.add("wrong");

  if (correct) {
    solo.combo += 1;
    solo.bestCombo = Math.max(solo.bestCombo, solo.combo);
    solo.correct += 1;
    solo.energy = Math.min(5, solo.energy + 1);
    solo.crystals += 1;
    solo.score += 100 + Math.max(0, Math.floor((18000 - elapsed) / 360)) + Math.min(5, solo.combo) * 8;
    showFeedback(true, solo.index >= solo.questions.length - 3 ? "能量命中！" : "穿越成功！", `+${100 + Math.max(0, Math.floor((18000 - elapsed) / 360))} 能量分`);
    playTone("correct");
  } else {
    solo.combo = 0;
    solo.hearts -= 1;
    solo.wrongQuestions.push(question);
    showFeedback(false, answer === null ? "时间到，救援启动" : "撞上干扰门了", question.hint);
    playTone("wrong");
  }
  updateSoloHud();

  const outOfHearts = solo.hearts <= 0;
  setTimeout(() => {
    if (!solo) return;
    if (outOfHearts && !solo.rescueUsed) {
      solo.rescueUsed = true;
      solo.hearts = 2;
      toast("机器人启动救援装置，恢复 2 颗护盾");
    } else if (outOfHearts) {
      finishSolo(false);
      return;
    }
    solo.index += 1;
    renderSoloQuestion();
  }, 1150);
}

function finishSolo(success) {
  clearTimeout(soloTimer);
  const total = solo.questions.length;
  const accuracy = total ? solo.correct / total : 0;
  const stars = accuracy >= .9 ? 3 : accuracy >= .7 ? 2 : accuracy >= .6 ? 1 : 0;
  elements.resultStars.textContent = stars ? "★ ".repeat(stars).trim() : "☆ ☆ ☆";
  elements.resultStars.setAttribute("aria-label", `获得${stars}星`);
  elements.resultKicker.textContent = solo.repair ? "错题修复完成" : "星球任务完成";
  elements.resultTitle.textContent = success ? (stars >= 2 ? "闯关成功！" : "成功抵达基地") : "护盾能量耗尽";
  elements.resultScore.textContent = solo.score;
  elements.resultCorrect.textContent = `${solo.correct} / ${total}`;
  elements.resultCombo.textContent = solo.bestCombo;
  elements.resultCrystals.textContent = solo.crystals;
  elements.battleRanking.classList.add("hidden");
  elements.playAgain.querySelector("strong").textContent = solo.wrongQuestions.length ? `修复 ${solo.wrongQuestions.length} 道错题` : "再来一局";
  lastResult = { type: "solo", wrongQuestions: [...solo.wrongQuestions] };
  showScreen(elements.result);
  if (success) playTone("win");
  persistSoloRecord({ score: solo.score, correct: solo.correct, total, mode: selectedMode, at: Date.now() });
}

function persistSoloRecord(record) {
  try {
    const records = JSON.parse(localStorage.getItem("arithmetic-records") || "[]");
    records.unshift(record);
    localStorage.setItem("arithmetic-records", JSON.stringify(records.slice(0, 30)));
  } catch {
    // Private browsing can disable storage without affecting the game.
  }
}

function openBattle() {
  currentGame = null;
  elements.battleEntry.classList.remove("hidden");
  elements.battleLobby.classList.add("hidden");
  elements.battleError.textContent = "";
  showScreen(elements.battle);
  connectBattle();
}

function socketUrl() {
  const protocol = location.protocol === "https:" ? "wss:" : "ws:";
  return `${protocol}//${location.host}/ws`;
}

function connectBattle() {
  if (battle.socket?.readyState === WebSocket.OPEN) return Promise.resolve(battle.socket);
  if (battle.connecting) return battle.connecting;
  battle.connecting = new Promise((resolve, reject) => {
    const socket = new WebSocket(socketUrl());
    battle.socket = socket;
    elements.networkStatus.className = "network-status";
    elements.networkStatus.lastChild.textContent = "连接中";

    socket.addEventListener("open", () => {
      battle.connecting = null;
      elements.networkStatus.className = "network-status online";
      elements.networkStatus.lastChild.textContent = "已连接";
      resolve(socket);
      if (battle.token && !battle.playerId) socket.send(JSON.stringify({ type: "reconnect", token: battle.token }));
    });
    socket.addEventListener("message", (event) => handleBattleMessage(JSON.parse(event.data)));
    socket.addEventListener("close", () => {
      battle.connecting = null;
      elements.networkStatus.className = "network-status offline";
      elements.networkStatus.lastChild.textContent = "连接中断";
      if (currentGame === "battle") showFeedback(false, "连接中断", "正在等待重新连接，请保持页面打开");
    });
    socket.addEventListener("error", () => reject(new Error("SOCKET_FAILED")));
  });
  return battle.connecting;
}

async function sendBattle(payload) {
  try {
    const socket = await connectBattle();
    socket.send(JSON.stringify(payload));
  } catch {
    elements.battleError.textContent = "暂时无法连接对战服务，请稍后重试";
  }
}

function handleBattleMessage(message) {
  if (message.type === "room_created" || message.type === "room_joined") {
    battle.playerId = message.playerId;
    battle.token = message.token;
    battle.room = message.room;
    sessionStorage.setItem("arithmetic-battle-token", battle.token);
    showBattleLobby();
    updateRoom(message.room);
  } else if (message.type === "reconnected") {
    battle.playerId = message.playerId;
    battle.room = message.room;
    if (message.room.status === "lobby" || message.room.status === "countdown") {
      showBattleLobby();
      updateRoom(message.room);
    }
  } else if (message.type === "room_state") {
    battle.room = message.room;
    updateRoom(message.room);
  } else if (message.type === "countdown") {
    currentGame = "battle";
    prepareBattleGame();
    runCountdown(message.startsAt);
  } else if (message.type === "question") {
    renderBattleQuestion(message);
  } else if (message.type === "answer_ack") {
    const detail = message.timeout ? "时间到，本题没有得分" : "答案已锁定，等待对手";
    showFeedback(message.correct, message.correct ? "能量锁定！" : "护盾受到干扰", detail);
    playTone(message.correct ? "correct" : "wrong");
  } else if (message.type === "round_reveal") {
    const correctLane = battle.question?.choices.indexOf(message.correctAnswer);
    if (correctLane >= 0) elements.gates[correctLane].classList.add("correct");
    updateBattleScores(message.players);
  } else if (message.type === "match_end") {
    finishBattle(message);
  } else if (message.type === "error") {
    if (message.code === "SESSION_NOT_FOUND") {
      battle.token = null;
      battle.playerId = null;
      sessionStorage.removeItem("arithmetic-battle-token");
    }
    elements.battleError.textContent = message.message;
    toast(message.message);
  }
}

function showBattleLobby() {
  showScreen(elements.battle);
  elements.battleEntry.classList.add("hidden");
  elements.battleLobby.classList.remove("hidden");
}

function updateRoom(room) {
  elements.roomCode.textContent = room.code.split("").join(" ");
  elements.waitingCopy.textContent = room.players.length < 2 ? "把房间码发给好友，等待对方加入" : "对手已加入，双方准备后立即开赛";
  elements.playerSlots.forEach((slot, index) => {
    const player = room.players[index];
    slot.classList.toggle("ready", Boolean(player?.ready));
    slot.querySelector(".slot-avatar").textContent = index === 0 ? "🚀" : player ? "⚡" : "?";
    slot.querySelector("strong").textContent = player?.name || "等待玩家";
    slot.querySelector("small").textContent = !player ? "未加入" : player.ready ? "已准备" : player.connected ? "未准备" : "连接中断";
  });

  const me = room.players.find((player) => player.id === battle.playerId);
  if (room.players.length < 2) {
    elements.ready.disabled = true;
    elements.ready.querySelector("strong").textContent = "等待好友加入";
  } else if (me?.ready) {
    elements.ready.disabled = true;
    elements.ready.querySelector("strong").textContent = "已准备，等待对手";
  } else {
    elements.ready.disabled = false;
    elements.ready.querySelector("strong").textContent = "准备出发";
  }

  if (currentGame === "battle") updateBattleScores(room.players);
}

function prepareBattleGame() {
  clearTimeout(soloTimer);
  currentGame = "battle";
  battle.locked = true;
  elements.soloHud.classList.add("hidden");
  elements.battleHud.classList.remove("hidden");
  elements.opponent.classList.remove("hidden");
  elements.battleRanking.classList.add("hidden");
  elements.expression.textContent = "双方已就位";
  elements.sceneLabel.textContent = "好友竞速赛";
  elements.questionProgress.textContent = "准备";
  setBossStage(false);
  disableGates();
  updateBattleScores(battle.room?.players || []);
  showScreen(elements.game);
}

function runCountdown(startsAt) {
  clearInterval(battle.countdownTimer);
  elements.countdown.classList.remove("hidden");
  const tick = () => {
    const remaining = Math.ceil((startsAt - Date.now()) / 1000);
    elements.countdown.querySelector("strong").textContent = remaining > 0 ? remaining : "GO";
    if (remaining <= 0) {
      clearInterval(battle.countdownTimer);
      setTimeout(() => elements.countdown.classList.add("hidden"), 450);
      playTone("start");
    }
  };
  tick();
  battle.countdownTimer = setInterval(tick, 250);
}

function renderBattleQuestion(message) {
  if (currentGame !== "battle") prepareBattleGame();
  battle.question = message.question;
  battle.locked = false;
  battle.selectedLane = 1;
  hideFeedback();
  elements.runner.classList.remove("commit");
  elements.expression.textContent = message.question.expression;
  elements.questionProgress.textContent = `${message.number} / ${message.total}`;
  elements.battleRound.textContent = message.number;
  elements.progress.style.width = `${((message.number - 1) / message.total) * 100}%`;
  elements.sceneLabel.textContent = message.number > message.total - 3 ? "终局 · BOSS竞速" : "实时答案门";
  setBossStage(message.number > message.total - 3, message.number - (message.total - 3) - 1);
  setGates(message.question.choices);
  const elapsed = Math.max(0, Date.now() - message.startedAt);
  setQuestionTimer(message.durationMs / 1000, elapsed);
}

function chooseBattleLane(lane) {
  if (!battle.question || battle.locked) return;
  battle.locked = true;
  battle.selectedLane = lane;
  moveRunner(lane, true);
  elements.world.classList.add("running");
  disableGates();
  playTone("select");
  sendBattle({
    type: "answer",
    questionId: battle.question.id,
    answer: Number(elements.gates[lane].dataset.answer)
  });
}

function updateBattleScores(players) {
  const me = players.find((player) => player.id === battle.playerId);
  const rival = players.find((player) => player.id !== battle.playerId);
  elements.myScore.textContent = me?.score || 0;
  elements.rivalScore.textContent = rival?.score || 0;
  if (rival) {
    const lane = (rival.answered + rival.combo) % 3;
    for (let index = 0; index < 3; index += 1) elements.opponent.classList.toggle(`lane-${index}`, index === lane);
  }
}

function finishBattle(message) {
  elements.countdown.classList.add("hidden");
  elements.timeFill.classList.remove("active");
  const me = message.ranking.find((player) => player.id === battle.playerId);
  const won = message.winnerId === battle.playerId;
  const draw = message.draw;
  elements.resultStars.textContent = won ? "★ ★ ★" : draw ? "★ ★" : "★";
  elements.resultKicker.textContent = "1v1 好友对战结束";
  elements.resultTitle.textContent = draw ? "势均力敌！" : won ? "竞速胜利！" : "再挑战一次吧";
  elements.resultScore.textContent = me?.score || 0;
  elements.resultCorrect.textContent = `${me?.correct || 0} / 10`;
  elements.resultCombo.textContent = me?.bestCombo || 0;
  elements.resultCrystals.textContent = me?.correct || 0;
  elements.battleRanking.innerHTML = message.ranking.map((player, index) => `
    <div class="ranking-row ${index === 0 && !draw ? "winner" : ""}">
      <span>${index + 1}</span><strong>${escapeHtml(player.name)}</strong><small>${player.correct}/10</small><b>${player.score} 分</b>
    </div>
  `).join("");
  elements.battleRanking.classList.remove("hidden");
  elements.playAgain.querySelector("strong").textContent = "创建新对战";
  lastResult = { type: "battle", wrongQuestions: [] };
  battle.socket?.close();
  battle.socket = null;
  battle.token = null;
  battle.playerId = null;
  battle.room = null;
  sessionStorage.removeItem("arithmetic-battle-token");
  showScreen(elements.result);
  if (won || draw) playTone("win");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character]));
}

function leaveCurrentGame() {
  clearTimeout(soloTimer);
  if (currentGame === "battle" || battle.playerId || battle.socket) {
    battle.socket?.close();
    battle.socket = null;
    battle.playerId = null;
    battle.token = null;
    battle.room = null;
    sessionStorage.removeItem("arithmetic-battle-token");
  }
  currentGame = null;
  showScreen(elements.home);
}

elements.soundToggle.addEventListener("click", toggleSound);
elements.gameSound.addEventListener("click", toggleSound);
elements.soloStart.addEventListener("click", () => startSolo());
elements.battleOpen.addEventListener("click", openBattle);
for (const chip of $$(".mode-chip")) chip.addEventListener("click", () => setMode(chip.dataset.mode));
for (const button of $$("[data-back-home]")) button.addEventListener("click", leaveCurrentGame);
elements.gameExit.addEventListener("click", leaveCurrentGame);

elements.gates.forEach((gate, lane) => {
  gate.addEventListener("click", () => currentGame === "battle" ? chooseBattleLane(lane) : chooseSoloLane(lane));
});

document.addEventListener("keydown", (event) => {
  if (!elements.game.classList.contains("active")) return;
  const lane = { "1": 0, "ArrowLeft": 0, "2": 1, "ArrowUp": 1, "3": 2, "ArrowRight": 2 }[event.key];
  if (lane === undefined) return;
  event.preventDefault();
  currentGame === "battle" ? chooseBattleLane(lane) : chooseSoloLane(lane);
});

let touchStartX = null;
elements.world.addEventListener("touchstart", (event) => { touchStartX = event.changedTouches[0].clientX; }, { passive: true });
elements.world.addEventListener("touchend", (event) => {
  if (touchStartX === null) return;
  const delta = event.changedTouches[0].clientX - touchStartX;
  touchStartX = null;
  if (Math.abs(delta) < 45) return;
  const lane = delta > 0 ? 2 : 0;
  currentGame === "battle" ? chooseBattleLane(lane) : chooseSoloLane(lane);
}, { passive: true });

elements.createRoom.addEventListener("click", () => {
  elements.battleError.textContent = "";
  sendBattle({ type: "create_room", player: { name: elements.playerName.value, avatar: "blue" } });
});

elements.joinRoom.addEventListener("click", () => {
  const code = elements.codeInput.value.trim().toUpperCase();
  if (code.length !== 5) {
    elements.battleError.textContent = "请输入完整的5位房间码";
    return;
  }
  elements.battleError.textContent = "";
  sendBattle({ type: "join_room", code, player: { name: elements.playerName.value, avatar: "orange" } });
});

elements.codeInput.addEventListener("input", () => {
  elements.codeInput.value = elements.codeInput.value.replace(/[^a-zA-Z0-9]/g, "").toUpperCase().slice(0, 5);
});

elements.copyCode.addEventListener("click", async () => {
  if (!battle.room?.code) return;
  try {
    await navigator.clipboard.writeText(battle.room.code);
    toast("房间码已复制，发给好友吧");
  } catch {
    toast(`房间码：${battle.room.code}`);
  }
});

elements.ready.addEventListener("click", () => {
  elements.ready.disabled = true;
  elements.ready.querySelector("strong").textContent = "已准备";
  sendBattle({ type: "ready", ready: true, mode: selectedMode });
});

elements.playAgain.addEventListener("click", () => {
  if (lastResult.type === "battle") {
    openBattle();
    return;
  }
  if (lastResult.wrongQuestions.length) {
    const variants = createQuestionSet({ mode: selectedMode, count: Math.min(6, Math.max(2, lastResult.wrongQuestions.length)), seed: `repair-${Date.now()}` });
    startSolo({ repairQuestions: [...lastResult.wrongQuestions, ...variants] });
  } else {
    startSolo();
  }
});

elements.resultHome.addEventListener("click", leaveCurrentGame);

updateSoundButtons();
setMode("mixed");
