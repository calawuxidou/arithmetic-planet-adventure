import { access, cp, mkdir, rm } from "node:fs/promises";
import { constants } from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const required = [
  "public/index.html",
  "public/styles.css",
  "public/app.js",
  "public/assets/robot.webp",
  "public/assets/boss.webp",
  "public/assets/track-bg.webp",
  "server/index.js",
  "shared/questions.js",
  "shared/game-data.js"
];

for (const file of required) {
  await access(path.join(root, file), constants.R_OK);
}

const dist = path.join(root, "dist");
await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });
await cp(path.join(root, "public"), dist, { recursive: true });
await cp(path.join(root, "shared"), path.join(dist, "shared"), { recursive: true });

console.log("Build complete: dist/ is ready.");
