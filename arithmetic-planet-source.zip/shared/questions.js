const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export function hashSeed(value = "arithmetic-planet") {
  let hash = 2166136261;
  for (const char of String(value)) {
    hash ^= char.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function seededRandom(seed) {
  let state = typeof seed === "number" ? seed >>> 0 : hashSeed(seed);
  return () => {
    state += 0x6d2b79f5;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

const pick = (rng, list) => list[Math.floor(rng() * list.length)];
const integer = (rng, min, max) => Math.floor(rng() * (max - min + 1)) + min;

function makeChoices(answer, rng, extra = []) {
  const values = new Set([answer]);
  for (const candidate of extra) {
    if (Number.isInteger(candidate) && candidate >= 0 && candidate <= 200) values.add(candidate);
  }
  const offsets = [-15, -12, -10, -8, -6, -5, -3, -2, -1, 1, 2, 3, 5, 6, 8, 10, 12, 15];
  while (values.size < 3) values.add(clamp(answer + pick(rng, offsets), 0, 200));
  const choices = [...values].slice(0, 3);
  for (let index = choices.length - 1; index > 0; index -= 1) {
    const target = Math.floor(rng() * (index + 1));
    [choices[index], choices[target]] = [choices[target], choices[index]];
  }
  return choices;
}

function finalize({ rng, index, expression, answer, kind, difficulty, category, hint, steps, distractors = [] }) {
  return {
    id: `q-${index}-${Math.floor(rng() * 1e8)}`,
    expression: `${expression} = ?`,
    answer,
    choices: makeChoices(answer, rng, distractors),
    kind,
    difficulty,
    category,
    hint,
    steps: [...steps, `所以答案是 ${answer}`]
  };
}

function oneStepQuestion(rng, index, focus, difficulty) {
  const kind = focus === "mixed" ? pick(rng, ["multiply", "divide", "support"]) : focus;
  if (kind === "divide") {
    const divisor = integer(rng, 2, 9);
    const answer = integer(rng, 2, difficulty >= 2 ? 12 : 9);
    const dividend = divisor * answer;
    return finalize({
      rng, index, difficulty, kind,
      expression: `${dividend} ÷ ${divisor}`,
      answer,
      category: "除法充能",
      hint: `想：${divisor} ×（ ）= ${dividend}`,
      steps: [`${divisor} × ${answer} = ${dividend}`, `${dividend} ÷ ${divisor} = ${answer}`],
      distractors: [divisor, answer + divisor]
    });
  }
  if (kind === "support") {
    const useSubtract = rng() > 0.48;
    if (useSubtract) {
      const left = integer(rng, 24, difficulty >= 2 ? 99 : 70);
      const right = integer(rng, 5, left - 3);
      return finalize({
        rng, index, difficulty, kind,
        expression: `${left} - ${right}`,
        answer: left - right,
        category: "修复能量",
        hint: "从总能量中减去已经消耗的能量",
        steps: [`${left} - ${right} = ${left - right}`],
        distractors: [left + right, left - right + 10]
      });
    }
    const left = integer(rng, 12, 58);
    const right = integer(rng, 8, Math.min(40, 100 - left));
    return finalize({
      rng, index, difficulty, kind,
      expression: `${left} + ${right}`,
      answer: left + right,
      category: "修复能量",
      hint: "把两部分能量合在一起",
      steps: [`${left} + ${right} = ${left + right}`],
      distractors: [left + right - 10, Math.abs(left - right)]
    });
  }
  const a = integer(rng, 2, 9);
  const b = integer(rng, 2, difficulty >= 2 ? 12 : 9);
  return finalize({
    rng, index, difficulty, kind: "multiply",
    expression: `${a} × ${b}`,
    answer: a * b,
    category: "乘法充能",
    hint: `想一想 ${a} 的 ${b} 倍是多少`,
    steps: [`${a} × ${b} = ${a * b}`],
    distractors: [a + b, a * b - a]
  });
}

function twoStepQuestion(rng, index, focus, difficulty) {
  if (focus === "multiply") {
    const a = integer(rng, 2, 8);
    const b = integer(rng, 2, 9);
    const c = integer(rng, 2, 5);
    const answer = a * b + c;
    return finalize({ rng, index, difficulty, kind: "multiply", expression: `${a} × ${b} + ${c}`, answer, category: "分裂弹强化", hint: "先算乘法，再算加法", steps: [`${a} × ${b} = ${a * b}`, `${a * b} + ${c} = ${answer}`], distractors: [a * (b + c), a * b] });
  }
  if (focus === "divide") {
    const divisor = integer(rng, 2, 8);
    const quotient = integer(rng, 2, 9);
    const add = integer(rng, 3, 18);
    const dividend = divisor * quotient;
    const answer = quotient + add;
    return finalize({ rng, index, difficulty, kind: "divide", expression: `${dividend} ÷ ${divisor} + ${add}`, answer, category: "激光强化", hint: "先算除法，再算加法", steps: [`${dividend} ÷ ${divisor} = ${quotient}`, `${quotient} + ${add} = ${answer}`], distractors: [dividend / (divisor + add), dividend + add] });
  }
  if (focus === "support") {
    const left = integer(rng, 35, 80);
    const subtract = integer(rng, 8, left - 8);
    const add = integer(rng, 5, 22);
    const answer = left - subtract + add;
    return finalize({ rng, index, difficulty, kind: "support", expression: `${left} - ${subtract} + ${add}`, answer, category: "紧急修复", hint: "加减法同级，从左往右计算", steps: [`${left} - ${subtract} = ${left - subtract}`, `${left - subtract} + ${add} = ${answer}`], distractors: [left - (subtract + add), left + subtract - add] });
  }

  const pattern = integer(rng, 0, 3);
  const a = integer(rng, 2, 9);
  const b = integer(rng, 2, 9);
  if (pattern === 0) {
    const c = integer(rng, 4, 20);
    const answer = a * b + c;
    return finalize({ rng, index, difficulty, kind: "mixed", expression: `${a} × ${b} + ${c}`, answer, category: "战术混合", hint: "先乘除，后加减", steps: [`${a} × ${b} = ${a * b}`, `${a * b} + ${c} = ${answer}`], distractors: [a * (b + c), a * b] });
  }
  if (pattern === 1) {
    const product = a * b;
    const subtract = integer(rng, 2, Math.max(2, product - 1));
    const answer = product - subtract;
    return finalize({ rng, index, difficulty, kind: "mixed", expression: `${a} × ${b} - ${subtract}`, answer, category: "战术混合", hint: "先算乘法，再算减法", steps: [`${a} × ${b} = ${product}`, `${product} - ${subtract} = ${answer}`], distractors: [a * Math.max(0, b - subtract), product] });
  }
  const divisor = integer(rng, 2, 8);
  const quotient = integer(rng, 2, 9);
  const dividend = divisor * quotient;
  const c = integer(rng, 4, 20);
  if (pattern === 2) {
    const answer = dividend / divisor + c;
    return finalize({ rng, index, difficulty, kind: "mixed", expression: `${dividend} ÷ ${divisor} + ${c}`, answer, category: "战术混合", hint: "先算除法，再算加法", steps: [`${dividend} ÷ ${divisor} = ${quotient}`, `${quotient} + ${c} = ${answer}`], distractors: [dividend / (divisor + c), dividend + c] });
  }
  const multiplier = integer(rng, 2, 5);
  const answer = quotient * multiplier;
  return finalize({ rng, index, difficulty, kind: "mixed", expression: `${dividend} ÷ ${divisor} × ${multiplier}`, answer, category: "战术混合", hint: "乘除法同级，从左往右计算", steps: [`${dividend} ÷ ${divisor} = ${quotient}`, `${quotient} × ${multiplier} = ${answer}`], distractors: [dividend / (divisor * multiplier), dividend] });
}

function threeStepQuestion(rng, index, focus, difficulty) {
  const kind = focus === "support" ? "support" : focus === "multiply" ? "multiply" : focus === "divide" ? "divide" : "mixed";
  if (kind === "support") {
    const a = integer(rng, 45, 85);
    const b = integer(rng, 10, 30);
    const c = integer(rng, 5, 18);
    const answer = a - b + c;
    return finalize({ rng, index, difficulty, kind, expression: `${a} - ${b} + ${c}`, answer, category: "星级修复", hint: "加减法同级，从左往右计算", steps: [`${a} - ${b} = ${a - b}`, `${a - b} + ${c} = ${answer}`], distractors: [a - b - c, a + b - c] });
  }

  const a = integer(rng, 2, 8);
  const b = integer(rng, 2, 8);
  const divisor = integer(rng, 2, 7);
  const quotient = integer(rng, 2, 8);
  const dividend = divisor * quotient;
  const subtract = integer(rng, 2, Math.max(2, a * b + quotient - 1));
  const answer = a * b + quotient - subtract;
  return finalize({
    rng, index, difficulty, kind,
    expression: `${a} × ${b} + ${dividend} ÷ ${divisor} - ${subtract}`,
    answer,
    category: "星核极限题",
    hint: "先分别算乘法和除法，再从左往右加减",
    steps: [`${a} × ${b} = ${a * b}`, `${dividend} ÷ ${divisor} = ${quotient}`, `${a * b} + ${quotient} - ${subtract} = ${answer}`],
    distractors: [(a * (b + dividend)) / divisor - subtract, a * b + quotient]
  });
}

export function createCombatQuestion({ difficulty = 1, focus = "mixed", seed = Date.now(), index = 0 } = {}) {
  const rank = Math.max(1, Math.min(3, Number(difficulty) || 1));
  const normalizedFocus = ["multiply", "divide", "support", "mixed"].includes(focus) ? focus : "mixed";
  const rng = seededRandom(`${seed}-${index}-${rank}-${normalizedFocus}`);
  if (rank === 1) return oneStepQuestion(rng, index, normalizedFocus, rank);
  if (rank === 2) return twoStepQuestion(rng, index, normalizedFocus, rank);
  return threeStepQuestion(rng, index, normalizedFocus, rank);
}

export function createQuestionSet({ mode = "mixed", count = 10, seed = Date.now() } = {}) {
  const pattern = [1, 1, 2, 1, 2, 3, 2, 2, 3, 3];
  return Array.from({ length: count }, (_, index) => {
    const focus = mode === "muldiv" ? (index % 2 ? "divide" : "multiply") : "mixed";
    return createCombatQuestion({ difficulty: pattern[index % pattern.length], focus, seed, index });
  });
}

export function publicQuestion(question) {
  const { answer: _answer, steps: _steps, hint: _hint, ...safe } = question;
  return safe;
}

export function checkAnswer(question, answer) {
  return Number(answer) === question.answer;
}
