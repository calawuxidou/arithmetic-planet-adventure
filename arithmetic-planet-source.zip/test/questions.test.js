import test from "node:test";
import assert from "node:assert/strict";
import { checkAnswer, createQuestionSet, publicQuestion } from "../shared/questions.js";

test("question sets are deterministic for the same seed", () => {
  const first = createQuestionSet({ mode: "mixed", count: 10, seed: "same-room" });
  const second = createQuestionSet({ mode: "mixed", count: 10, seed: "same-room" });
  assert.deepEqual(first, second);
});

test("every question has exactly three unique choices and one correct answer", () => {
  for (const mode of ["muldiv", "mixed"]) {
    const questions = createQuestionSet({ mode, count: 100, seed: `validate-${mode}` });
    for (const question of questions) {
      assert.equal(question.choices.length, 3);
      assert.equal(new Set(question.choices).size, 3);
      assert.equal(question.choices.filter((choice) => choice === question.answer).length, 1);
      assert.equal(checkAnswer(question, question.answer), true);
      assert.equal(Number.isInteger(question.answer), true);
      assert.ok(question.answer >= 0);
    }
  }
});

test("generated answers match the visible arithmetic expressions", () => {
  for (const mode of ["muldiv", "mixed"]) {
    const questions = createQuestionSet({ mode, count: 1000, seed: `math-${mode}` });
    for (const question of questions) {
      const arithmetic = question.expression
        .replace("= ?", "")
        .replaceAll("×", "*")
        .replaceAll("÷", "/");
      const evaluated = Function(`"use strict"; return (${arithmetic});`)();
      assert.equal(question.answer, evaluated, question.expression);
    }
  }
});

test("public battle questions do not expose answers or teaching steps", () => {
  const [question] = createQuestionSet({ mode: "mixed", count: 1, seed: "privacy" });
  const safe = publicQuestion(question);
  assert.equal("answer" in safe, false);
  assert.equal("steps" in safe, false);
  assert.equal("hint" in safe, false);
});
