const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export function hashSeed(value = "arithmetic-planet") {
  let hash = 2166136261;
  for (const char of String(value)) {
    hash ^= char.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function seededRandom(seed) {
  let state = typeof seed === "number" ? seed >>> 0 : hashSeed(seed);
  return () => {
    state += 0x6d2b79f5;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

const pick = (rng, list) => list[Math.floor(rng() * list.length)];
const integer = (rng, min, max) => Math.floor(rng() * (max - min + 1)) + min;

function makeChoices(answer, rng, extra = []) {
  const values = new Set([answer]);
  for (const candidate of extra) {
    if (Number.isInteger(candidate) && candidate >= 0 && candidate <= 150) values.add(candidate);
  }

  const offsets = [-12, -10, -8, -6, -5, -3, -2, -1, 1, 2, 3, 5, 6, 8, 10, 12];
  while (values.size < 3) {
    values.add(clamp(answer + pick(rng, offsets), 0, 150));
  }

  const choices = [...values].slice(0, 3);
  for (let index = choices.length - 1; index > 0; index -= 1) {
    const target = Math.floor(rng() * (index + 1));
    [choices[index], choices[target]] = [choices[target], choices[index]];
  }
  return choices;
}

function multiplicationQuestion(rng, index) {
  const a = integer(rng, 2, 9);
  const b = integer(rng, 2, 9);
  const useDivision = rng() > 0.48;
  if (useDivision) {
    const product = a * b;
    return {
      id: `q-${index}-${Math.floor(rng() * 1e8)}`,
      expression: `${product} ÷ ${a} = ?`,
      answer: b,
      choices: makeChoices(b, rng, [a, product - a]),
      category: "表内除法",
      hint: `把除法想成乘法：${a} ×（ ）= ${product}`,
      steps: [`${product} ÷ ${a}`, `想：${a} × ${b} = ${product}`, `所以答案是 ${b}`]
    };
  }

  const answer = a * b;
  return {
    id: `q-${index}-${Math.floor(rng() * 1e8)}`,
    expression: `${a} × ${b} = ?`,
    answer,
    choices: makeChoices(answer, rng, [a + b, answer - a]),
    category: "表内乘法",
    hint: `想一想 ${a} 的 ${b} 倍是多少`,
    steps: [`${a} × ${b}`, `使用乘法口诀`, `答案是 ${answer}`]
  };
}

function chainQuestion(rng, index) {
  const a = integer(rng, 2, 8);
  const b = integer(rng, 2, 7);
  const divisor = pick(rng, [a, b]);
  const first = a * b;
  const answer = first / divisor;
  return {
    id: `q-${index}-${Math.floor(rng() * 1e8)}`,
    expression: `${first} ÷ ${divisor} × ${integer(rng, 2, 5)} = ?`,
    category: "乘除混合",
    hint: "乘法和除法同级，要从左往右计算",
    _chain: { first, divisor, answer }
  };
}

function finalizeChain(question, rng) {
  const multiplier = Number(question.expression.match(/× (\d+)/)?.[1] || 2);
  const answer = question._chain.answer * multiplier;
  return {
    ...question,
    answer,
    choices: makeChoices(answer, rng, [question._chain.first / (question._chain.divisor * multiplier), question._chain.first]),
    steps: [
      `${question._chain.first} ÷ ${question._chain.divisor} = ${question._chain.answer}`,
      `${question._chain.answer} × ${multiplier} = ${answer}`,
      `所以答案是 ${answer}`
    ],
    _chain: undefined
  };
}

function mixedQuestion(rng, index, allowParentheses = false) {
  const pattern = allowParentheses ? integer(rng, 0, 5) : integer(rng, 0, 4);
  const a = integer(rng, 2, 9);
  const b = integer(rng, 2, 9);
  const c = integer(rng, 2, 18);
  let expression;
  let answer;
  let wrongOrder;
  let steps;

  if (pattern === 0) {
    answer = a * b + c;
    expression = `${a} × ${b} + ${c} = ?`;
    wrongOrder = a * (b + c);
    steps = [`先算 ${a} × ${b} = ${a * b}`, `再算 ${a * b} + ${c} = ${answer}`];
  } else if (pattern === 1) {
    const product = a * b;
    const subtract = integer(rng, 2, Math.max(2, product - 1));
    answer = product - subtract;
    expression = `${a} × ${b} - ${subtract} = ?`;
    wrongOrder = a * Math.max(0, b - subtract);
    steps = [`先算 ${a} × ${b} = ${product}`, `再算 ${product} - ${subtract} = ${answer}`];
  } else if (pattern === 2) {
    answer = c + a * b;
    expression = `${c} + ${a} × ${b} = ?`;
    wrongOrder = (c + a) * b;
    steps = [`先算 ${a} × ${b} = ${a * b}`, `再算 ${c} + ${a * b} = ${answer}`];
  } else if (pattern === 3) {
    const quotient = integer(rng, 2, 9);
    const divisor = integer(rng, 2, 9);
    const dividend = quotient * divisor;
    answer = dividend / divisor + c;
    expression = `${dividend} ÷ ${divisor} + ${c} = ?`;
    wrongOrder = dividend / (divisor + c);
    steps = [`先算 ${dividend} ÷ ${divisor} = ${quotient}`, `再算 ${quotient} + ${c} = ${answer}`];
  } else if (pattern === 4) {
    const quotient = integer(rng, 2, 8);
    const divisor = integer(rng, 2, 8);
    const dividend = quotient * divisor;
    answer = a * b + quotient;
    expression = `${a} × ${b} + ${dividend} ÷ ${divisor} = ?`;
    wrongOrder = (a * (b + dividend)) / divisor;
    steps = [`先算 ${a} × ${b} = ${a * b}`, `再算 ${dividend} ÷ ${divisor} = ${quotient}`, `最后算 ${a * b} + ${quotient} = ${answer}`];
  } else {
    const left = integer(rng, 4, 12);
    const right = integer(rng, 2, Math.min(8, left - 1));
    const multiplier = integer(rng, 2, 6);
    answer = (left - right) * multiplier;
    expression = `(${left} - ${right}) × ${multiplier} = ?`;
    wrongOrder = left - right * multiplier;
    steps = [`先算括号：${left} - ${right} = ${left - right}`, `再算 ${(left - right)} × ${multiplier} = ${answer}`];
  }

  return {
    id: `q-${index}-${Math.floor(rng() * 1e8)}`,
    expression,
    answer,
    choices: makeChoices(answer, rng, [Math.round(wrongOrder), answer + a]),
    category: pattern === 5 ? "括号挑战" : "四则混合",
    hint: pattern === 5 ? "有括号，先算括号里面" : "先乘除，后加减",
    steps: [...steps, `所以答案是 ${answer}`]
  };
}

export function createQuestionSet({ mode = "mixed", count = 10, seed = Date.now() } = {}) {
  const rng = seededRandom(seed);
  const questions = [];
  for (let index = 0; index < count; index += 1) {
    if (mode === "muldiv") {
      const useChain = index >= Math.ceil(count * 0.55) && rng() > 0.35;
      questions.push(useChain ? finalizeChain(chainQuestion(rng, index), rng) : multiplicationQuestion(rng, index));
    } else {
      const allowParentheses = index >= Math.ceil(count * 0.65);
      questions.push(mixedQuestion(rng, index, allowParentheses));
    }
  }
  return questions;
}

export function publicQuestion(question) {
  const { answer: _answer, steps: _steps, hint: _hint, ...safe } = question;
  return safe;
}

export function checkAnswer(question, answer) {
  return Number(answer) === question.answer;
}
