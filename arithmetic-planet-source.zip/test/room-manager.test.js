import test from "node:test";
import assert from "node:assert/strict";
import { setTimeout as delay } from "node:timers/promises";
import { RoomManager } from "../server/room-manager.js";

test("two players can join, ready up, receive identical questions and finish", async () => {
  const broadcasts = [];
  const direct = [];
  const manager = new RoomManager({
    countdownMs: 2,
    revealMs: 2,
    questionDurationMs: 1000,
    broadcast(room, message) { broadcasts.push({ code: room.code, message }); },
    direct(playerId, message) { direct.push({ playerId, message }); }
  });

  const host = manager.createRoom({ name: "队长" });
  const guest = manager.joinRoom(host.room.code, { name: "挑战者" });
  assert.equal(host.room.players.length, 2);
  assert.equal(host.room.status, "lobby");

  manager.setReady(host.player.id, true, "mixed");
  manager.setReady(guest.player.id, true, "mixed");
  await delay(8);
  assert.equal(host.room.status, "playing");
  assert.equal(host.room.questions.length, 10);

  for (let index = 0; index < 10; index += 1) {
    const question = host.room.questions[host.room.questionIndex];
    assert.ok(question);
    manager.submitAnswer(host.player.id, { questionId: question.id, answer: question.answer });
    manager.submitAnswer(guest.player.id, { questionId: question.id, answer: question.answer + 1 });
    await delay(5);
  }

  assert.equal(host.room.status, "finished");
  assert.equal(host.player.correct, 10);
  assert.equal(guest.player.correct, 0);
  assert.ok(host.player.score > guest.player.score);
  assert.ok(broadcasts.some(({ message }) => message.type === "match_end" && message.winnerId === host.player.id));
  assert.equal(direct.filter(({ message }) => message.type === "answer_ack").length, 20);
  manager.dispose();
});

test("a room rejects a third player", () => {
  const manager = new RoomManager();
  const host = manager.createRoom({ name: "A" });
  manager.joinRoom(host.room.code, { name: "B" });
  assert.throws(() => manager.joinRoom(host.room.code, { name: "C" }), /ROOM_FULL/);
  manager.dispose();
});

test("room snapshots never expose player tokens or answers", () => {
  const manager = new RoomManager();
  const { room } = manager.createRoom({ name: "安全测试" });
  const snapshot = manager.getSnapshot(room);
  assert.equal("token" in snapshot.players[0], false);
  assert.equal("questions" in snapshot, false);
  manager.dispose();
});
